import * as React from "react";

export const iconNames: string[];

export interface IconProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Icon name, e.g. "search", "plus", "setting". See `iconNames` for the full set. */
  name: string;
  /** Glyph size — any CSS length. Defaults to "1em" so it scales with font-size. */
  size?: number | string;
  /** Spin continuously (use for "loading"). */
  spin?: boolean;
  /** Static rotation in degrees. */
  rotate?: number;
}

/**
 * Ant Design outlined icon. Renders inline SVG that inherits `currentColor`.
 */
export function Icon(props: IconProps): JSX.Element;
