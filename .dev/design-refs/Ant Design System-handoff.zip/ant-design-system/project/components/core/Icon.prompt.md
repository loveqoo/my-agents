**Icon** — Ant Design outlined glyph; renders inline SVG that inherits the current text color and scales with font-size.

```jsx
<Icon name="search" />
<Icon name="loading" spin />
<Icon name="setting" size={20} style={{ color: "var(--color-primary)" }} />
```

Names match AntD's outlined set (without the `Outlined` suffix): `search`, `plus`, `close`, `check`, `down`, `up`, `left`, `right`, `setting`, `user`, `home`, `bell`, `mail`, `file`, `folder`, `delete`, `edit`, `ellipsis`, `menu`, `more`, `question-circle`, `info-circle`, `check-circle`, `close-circle`, `exclamation-circle`, `calendar`, `clock-circle`, `eye`, `star`, `heart`, `appstore`, `dashboard`, `team`, `logout`, `filter`, `reload`, `download`, `upload`, `loading`, `ant-design`. Import `iconNames` for the array. Use `size="1em"` (default) inside buttons/text so the glyph tracks the type.
