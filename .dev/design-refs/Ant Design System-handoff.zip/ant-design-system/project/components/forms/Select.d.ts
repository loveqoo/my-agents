import * as React from "react";

export interface SelectOption {
  label: React.ReactNode;
  value: string | number;
  disabled?: boolean;
}

export interface SelectProps {
  /** Options as strings or {label,value,disabled}. */
  options?: Array<string | SelectOption>;
  value?: string | number;
  defaultValue?: string | number;
  placeholder?: string;
  size?: "small" | "middle" | "large";
  disabled?: boolean;
  onChange?: (value: string | number) => void;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Ant Design select — pick one option from a dropdown. Closes on outside click.
 */
export function Select(props: SelectProps): JSX.Element;
