import * as React from "react";

export interface InputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "size" | "prefix"> {
  /** Control height: small 24 / middle 32 / large 40. @default "middle" */
  size?: "small" | "middle" | "large";
  /** Validation status — "error" paints the border red. */
  status?: "error" | "warning";
  disabled?: boolean;
  /** Leading content node. */
  prefix?: React.ReactNode;
  /** Trailing content node. */
  suffix?: React.ReactNode;
  /** Leading Ant icon name (convenience). */
  prefixIcon?: string;
  /** Trailing Ant icon name (convenience). */
  suffixIcon?: string;
  /** Show a clear (×) affix when there is a value. */
  allowClear?: boolean;
}

/**
 * Ant Design text input with optional affixes, sizes, status and clear button.
 */
export function Input(props: InputProps): JSX.Element;
