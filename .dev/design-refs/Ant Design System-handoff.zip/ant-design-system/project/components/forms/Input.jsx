import React from "react";
import { Icon } from "../core/Icon.jsx";

const CSS = `
.ads-input-wrap { display: inline-flex; align-items: center; width: 100%;
  background: var(--color-bg-container); border: 1px solid var(--color-border);
  border-radius: var(--radius); transition: all .2s; padding: 0 11px;
  height: var(--control-height); font-family: var(--font-family); font-size: 14px; color: var(--color-text); }
.ads-input-wrap--sm { height: var(--control-height-sm); padding: 0 7px; }
.ads-input-wrap--lg { height: var(--control-height-lg); padding: 0 11px; font-size: 16px; }
.ads-input-wrap:hover { border-color: var(--color-primary-hover); }
.ads-input-wrap--focused { border-color: var(--color-primary-hover); box-shadow: 0 0 0 2px rgba(5,145,255,.1); }
.ads-input-wrap--error { border-color: var(--color-error); }
.ads-input-wrap--error.ads-input-wrap--focused { box-shadow: 0 0 0 2px rgba(255,38,5,.06); }
.ads-input-wrap--disabled { background: var(--gray-3); cursor: not-allowed; color: var(--color-text-disabled); border-color: var(--color-border); }
.ads-input-wrap--disabled:hover { border-color: var(--color-border); }
.ads-input { flex: 1; min-width: 0; border: none; outline: none; background: transparent;
  font: inherit; color: inherit; padding: 0; }
.ads-input::placeholder { color: var(--color-text-quaternary); }
.ads-input:disabled { cursor: not-allowed; }
.ads-input-affix { display: inline-flex; align-items: center; color: var(--color-text-quaternary); }
.ads-input-affix--prefix { margin-right: 8px; }
.ads-input-affix--suffix { margin-left: 8px; }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "input");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Input({
  size = "middle",
  status,
  disabled = false,
  prefix,
  suffix,
  prefixIcon,
  suffixIcon,
  allowClear = false,
  value,
  defaultValue,
  onChange,
  className = "",
  style,
  ...rest
}) {
  inject();
  const [focused, setFocused] = React.useState(false);
  const [internal, setInternal] = React.useState(defaultValue ?? "");
  const isControlled = value !== undefined;
  const val = isControlled ? value : internal;

  const handle = (e) => {
    if (!isControlled) setInternal(e.target.value);
    onChange && onChange(e);
  };

  const wrapCls = [
    "ads-input-wrap",
    size === "small" && "ads-input-wrap--sm",
    size === "large" && "ads-input-wrap--lg",
    status === "error" && "ads-input-wrap--error",
    focused && "ads-input-wrap--focused",
    disabled && "ads-input-wrap--disabled",
    className,
  ].filter(Boolean).join(" ");

  const showClear = allowClear && val && !disabled;

  return (
    <span className={wrapCls} style={style}>
      {prefixIcon ? <span className="ads-input-affix ads-input-affix--prefix"><Icon name={prefixIcon} /></span> : null}
      {prefix ? <span className="ads-input-affix ads-input-affix--prefix">{prefix}</span> : null}
      <input
        className="ads-input"
        disabled={disabled}
        value={val}
        onChange={handle}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        {...rest}
      />
      {showClear ? (
        <span
          className="ads-input-affix ads-input-affix--suffix"
          style={{ cursor: "pointer" }}
          onMouseDown={(e) => { e.preventDefault();
            const ev = { target: { value: "" } };
            if (!isControlled) setInternal("");
            onChange && onChange(ev);
          }}
        ><Icon name="close-circle" /></span>
      ) : null}
      {suffix ? <span className="ads-input-affix ads-input-affix--suffix">{suffix}</span> : null}
      {suffixIcon ? <span className="ads-input-affix ads-input-affix--suffix"><Icon name={suffixIcon} /></span> : null}
    </span>
  );
}
