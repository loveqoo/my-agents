**Radio / RadioGroup** — choose exactly one option from a small visible set. Use `optionType="button"` for a segmented control.

```jsx
<RadioGroup defaultValue="a" options={["Apple", "Pear", "Orange"]} />
<RadioGroup defaultValue="list" optionType="button"
  options={[{label:"List",value:"list"},{label:"Grid",value:"grid"}]} />
```

`onChange(value)` returns the selected value. For many options prefer Select.
