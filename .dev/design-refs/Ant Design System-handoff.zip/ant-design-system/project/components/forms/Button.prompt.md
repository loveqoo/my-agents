**Button** — the primary action control; use for any clickable command. Five `type`s set hierarchy: `primary` for the main CTA, `default` for secondary, `dashed` for add/insert, `text` and `link` for low-emphasis inline actions.

```jsx
<Button type="primary">Submit</Button>
<Button>Cancel</Button>
<Button type="primary" iconName="plus">New</Button>
<Button type="primary" danger>Delete</Button>
<Button type="text" iconName="ellipsis" />
<Button type="primary" loading>Saving</Button>
```

Props: `type` (default·primary·dashed·text·link), `size` (small·middle·large), `danger`, `shape` (default·round·circle), `block`, `disabled`, `loading`, `iconName`/`icon`. Icon-only buttons render square when `children` is empty. One primary button per view.
