import * as React from "react";

export interface SwitchProps {
  /** Controlled on/off. */
  checked?: boolean;
  /** Uncontrolled initial state. */
  defaultChecked?: boolean;
  disabled?: boolean;
  /** "default" 22px tall, "small" 16px. */
  size?: "default" | "small";
  /** Label shown when on. */
  checkedChildren?: React.ReactNode;
  /** Label shown when off. */
  unCheckedChildren?: React.ReactNode;
  /** Fires with the next boolean value. */
  onChange?: (checked: boolean) => void;
  className?: string;
}

/**
 * Ant Design switch — instant on/off toggle for a single setting.
 */
export function Switch(props: SwitchProps): JSX.Element;
