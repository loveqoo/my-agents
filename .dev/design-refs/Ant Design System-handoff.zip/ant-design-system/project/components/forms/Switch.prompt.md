**Switch** — toggle a single setting on/off with immediate effect (no submit). For binary choices that take effect instantly; use Checkbox for form selection.

```jsx
<Switch defaultChecked />
<Switch size="small" />
<Switch checkedChildren="On" unCheckedChildren="Off" defaultChecked />
<Switch disabled />
```

`onChange(checked)` returns the next boolean.
