**Input** — single-line text field. Supports prefix/suffix nodes or icons, three sizes, `status="error"`, and `allowClear`.

```jsx
<Input placeholder="Basic usage" />
<Input prefixIcon="search" placeholder="Search" allowClear />
<Input size="large" suffix=".com" defaultValue="ant" />
<Input status="error" defaultValue="bad value" />
```

Controlled via `value`/`onChange` or uncontrolled via `defaultValue`. Pair with a label and help text in forms.
