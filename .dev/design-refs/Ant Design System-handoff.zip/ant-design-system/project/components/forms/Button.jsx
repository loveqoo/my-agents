import React from "react";
import { Icon } from "../core/Icon.jsx";

/* Inject component CSS once. Uses design-system tokens for all colors. */
const CSS = `
.ads-btn {
  display: inline-flex; align-items: center; justify-content: center; gap: 8px;
  font-family: var(--font-family); font-size: 14px; line-height: 1.5714;
  font-weight: var(--font-weight-normal); white-space: nowrap; text-align: center;
  height: var(--control-height); padding: 0 15px; border: 1px solid transparent;
  border-radius: var(--radius); cursor: pointer; user-select: none; outline: none;
  transition: all .2s cubic-bezier(.645,.045,.355,1);
}
.ads-btn--sm { height: var(--control-height-sm); padding: 0 7px; border-radius: var(--radius-sm); font-size: 14px; }
.ads-btn--lg { height: var(--control-height-lg); padding: 0 15px; border-radius: var(--radius-lg); font-size: 16px; }
.ads-btn--block { width: 100%; }
.ads-btn--round { border-radius: 100px; padding: 0 16px; }
.ads-btn--round.ads-btn--lg { padding: 0 20px; }
.ads-btn--circle { width: var(--control-height); padding: 0; border-radius: 50%; }
.ads-btn--circle.ads-btn--sm { width: var(--control-height-sm); }
.ads-btn--circle.ads-btn--lg { width: var(--control-height-lg); }
.ads-btn--icon-only { padding: 0; width: var(--control-height); }
.ads-btn--icon-only.ads-btn--sm { width: var(--control-height-sm); }
.ads-btn--icon-only.ads-btn--lg { width: var(--control-height-lg); }

/* default */
.ads-btn--default { background: var(--color-bg-container); border-color: var(--color-border); color: var(--color-text); box-shadow: 0 2px 0 rgba(0,0,0,.02); }
.ads-btn--default:hover { border-color: var(--color-primary-hover); color: var(--color-primary-hover); }
.ads-btn--default:active { border-color: var(--color-primary-active); color: var(--color-primary-active); }
/* dashed */
.ads-btn--dashed { background: var(--color-bg-container); border: 1px dashed var(--color-border); color: var(--color-text); box-shadow: 0 2px 0 rgba(0,0,0,.02); }
.ads-btn--dashed:hover { border-color: var(--color-primary-hover); color: var(--color-primary-hover); }
.ads-btn--dashed:active { border-color: var(--color-primary-active); color: var(--color-primary-active); }
/* primary */
.ads-btn--primary { background: var(--color-primary); border-color: var(--color-primary); color: #fff; box-shadow: 0 2px 0 rgba(5,145,255,.1); }
.ads-btn--primary:hover { background: var(--color-primary-hover); border-color: var(--color-primary-hover); color: #fff; }
.ads-btn--primary:active { background: var(--color-primary-active); border-color: var(--color-primary-active); }
/* text */
.ads-btn--text { background: transparent; border-color: transparent; color: var(--color-text); box-shadow: none; }
.ads-btn--text:hover { background: var(--color-fill-secondary); }
.ads-btn--text:active { background: var(--color-fill); }
/* link */
.ads-btn--link { background: transparent; border-color: transparent; color: var(--color-link); box-shadow: none; }
.ads-btn--link:hover { color: var(--color-link-hover); }
.ads-btn--link:active { color: var(--color-link-active); }

/* danger overrides */
.ads-btn--danger.ads-btn--primary { background: var(--color-error); border-color: var(--color-error); box-shadow: 0 2px 0 rgba(255,38,5,.06); }
.ads-btn--danger.ads-btn--primary:hover { background: var(--color-error-hover); border-color: var(--color-error-hover); }
.ads-btn--danger.ads-btn--primary:active { background: var(--color-error-active); border-color: var(--color-error-active); }
.ads-btn--danger.ads-btn--default, .ads-btn--danger.ads-btn--dashed { color: var(--color-error); border-color: var(--color-error); }
.ads-btn--danger.ads-btn--default:hover, .ads-btn--danger.ads-btn--dashed:hover { color: var(--color-error-hover); border-color: var(--color-error-hover); }
.ads-btn--danger.ads-btn--text { color: var(--color-error); }
.ads-btn--danger.ads-btn--text:hover { background: var(--color-error-bg); color: var(--color-error); }
.ads-btn--danger.ads-btn--link { color: var(--color-error); }
.ads-btn--danger.ads-btn--link:hover { color: var(--color-error-hover); }

/* disabled */
.ads-btn--disabled, .ads-btn--disabled:hover, .ads-btn--disabled:active {
  cursor: not-allowed; color: var(--color-text-disabled);
  background: var(--gray-3); border-color: var(--color-border); box-shadow: none;
}
.ads-btn--disabled.ads-btn--text, .ads-btn--disabled.ads-btn--link,
.ads-btn--disabled.ads-btn--text:hover, .ads-btn--disabled.ads-btn--link:hover {
  background: transparent; border-color: transparent; color: var(--color-text-disabled);
}
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "button");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Button({
  type = "default",
  size = "middle",
  danger = false,
  shape = "default",
  block = false,
  disabled = false,
  loading = false,
  icon,
  iconName,
  children,
  className = "",
  onClick,
  ...rest
}) {
  inject();
  const iconOnly = (icon || iconName || loading) && (children == null || children === "");
  const cls = [
    "ads-btn",
    `ads-btn--${type}`,
    size === "small" && "ads-btn--sm",
    size === "large" && "ads-btn--lg",
    danger && "ads-btn--danger",
    block && "ads-btn--block",
    shape === "round" && "ads-btn--round",
    shape === "circle" && "ads-btn--circle",
    iconOnly && shape === "default" && "ads-btn--icon-only",
    (disabled || loading) && "ads-btn--disabled",
    className,
  ].filter(Boolean).join(" ");

  const leadingIcon = loading
    ? <Icon name="loading" spin />
    : iconName
      ? <Icon name={iconName} />
      : icon || null;

  return (
    <button
      type="button"
      className={cls}
      disabled={disabled}
      onClick={disabled || loading ? undefined : onClick}
      {...rest}
    >
      {leadingIcon}
      {children != null && children !== "" ? <span>{children}</span> : null}
    </button>
  );
}
