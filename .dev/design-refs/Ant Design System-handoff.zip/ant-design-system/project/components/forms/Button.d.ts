import * as React from "react";

export type ButtonType = "default" | "primary" | "dashed" | "text" | "link";
export type ButtonSize = "small" | "middle" | "large";
export type ButtonShape = "default" | "round" | "circle";

/**
 * Props for the Ant Design button.
 *
 * @startingPoint section="Core" subtitle="Primary, default, dashed, text, link buttons" viewport="700x420"
 */
export interface ButtonProps
  extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "type"> {
  /** Visual style. @default "default" */
  type?: ButtonType;
  /** Control height: small 24 / middle 32 / large 40. @default "middle" */
  size?: ButtonSize;
  /** Danger (red) treatment for the chosen type. */
  danger?: boolean;
  /** Corner shape. @default "default" */
  shape?: ButtonShape;
  /** Stretch to full width of the container. */
  block?: boolean;
  /** Disabled state. */
  disabled?: boolean;
  /** Show a spinning loading glyph and block interaction. */
  loading?: boolean;
  /** Leading icon element (use for custom nodes). */
  icon?: React.ReactNode;
  /** Leading icon by Ant icon name, e.g. "plus" — convenience over `icon`. */
  iconName?: string;
  children?: React.ReactNode;
}

/**
 * Ant Design button. Five types, three sizes, danger + shape modifiers, icon and loading support.
 */
export function Button(props: ButtonProps): JSX.Element;
