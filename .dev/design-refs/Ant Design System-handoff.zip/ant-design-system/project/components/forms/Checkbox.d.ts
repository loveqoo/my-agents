import * as React from "react";

export interface CheckboxProps {
  checked?: boolean;
  defaultChecked?: boolean;
  /** Show the dash (mixed) state — used for "select all" parents. */
  indeterminate?: boolean;
  disabled?: boolean;
  onChange?: (e: { target: { checked: boolean } }) => void;
  children?: React.ReactNode;
  className?: string;
}

/**
 * Ant Design checkbox — multi-select within a group, or a single boolean opt-in.
 */
export function Checkbox(props: CheckboxProps): JSX.Element;
