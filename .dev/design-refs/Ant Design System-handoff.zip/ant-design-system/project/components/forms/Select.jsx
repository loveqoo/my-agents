import React from "react";
import { Icon } from "../core/Icon.jsx";

const CSS = `
.ads-select { position: relative; display: inline-block; width: 100%; font-family: var(--font-family); font-size: 14px; }
.ads-select-selector { display: flex; align-items: center; height: var(--control-height);
  padding: 0 11px; background: var(--color-bg-container); border: 1px solid var(--color-border);
  border-radius: var(--radius); cursor: pointer; transition: all .2s; color: var(--color-text); }
.ads-select--sm .ads-select-selector { height: var(--control-height-sm); }
.ads-select--lg .ads-select-selector { height: var(--control-height-lg); font-size: 16px; }
.ads-select-selector:hover { border-color: var(--color-primary-hover); }
.ads-select--open .ads-select-selector { border-color: var(--color-primary-hover); box-shadow: 0 0 0 2px rgba(5,145,255,.1); }
.ads-select--disabled .ads-select-selector { background: var(--gray-3); color: var(--color-text-disabled); cursor: not-allowed; }
.ads-select-value { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ads-select-placeholder { color: var(--color-text-quaternary); }
.ads-select-arrow { color: var(--color-text-quaternary); font-size: 12px; margin-left: 8px; transition: transform .2s; }
.ads-select--open .ads-select-arrow { transform: rotate(180deg); }
.ads-select-dropdown { position: absolute; top: calc(100% + 4px); left: 0; right: 0; z-index: 1050;
  background: var(--color-bg-elevated); border-radius: var(--radius-lg); box-shadow: var(--box-shadow-secondary);
  padding: 4px; max-height: 256px; overflow: auto; }
.ads-select-option { display: flex; align-items: center; justify-content: space-between; gap: 8px;
  padding: 5px 12px; border-radius: var(--radius-sm); cursor: pointer; color: var(--color-text);
  font-size: 14px; transition: background .2s; }
.ads-select-option:hover { background: var(--color-fill-tertiary); }
.ads-select-option--selected { background: var(--color-primary-bg); font-weight: var(--font-weight-medium); color: var(--color-text); }
.ads-select-option--selected:hover { background: var(--color-primary-bg); }
.ads-select-option--disabled { color: var(--color-text-disabled); cursor: not-allowed; }
.ads-select-check { color: var(--color-primary); font-size: 12px; }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "select");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Select({
  options = [],
  value,
  defaultValue,
  placeholder = "Please select",
  size = "middle",
  disabled = false,
  onChange,
  className = "",
  style,
  ...rest
}) {
  inject();
  const [open, setOpen] = React.useState(false);
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState(defaultValue);
  const val = isControlled ? value : internal;
  const ref = React.useRef(null);

  React.useEffect(() => {
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  const norm = options.map((o) => (typeof o === "object" ? o : { label: o, value: o }));
  const selected = norm.find((o) => o.value === val);

  const pick = (o) => {
    if (o.disabled) return;
    if (!isControlled) setInternal(o.value);
    onChange && onChange(o.value);
    setOpen(false);
  };

  const cls = [
    "ads-select",
    size === "small" && "ads-select--sm",
    size === "large" && "ads-select--lg",
    open && "ads-select--open",
    disabled && "ads-select--disabled",
    className,
  ].filter(Boolean).join(" ");

  return (
    <div className={cls} style={style} ref={ref} {...rest}>
      <div className="ads-select-selector" onClick={() => !disabled && setOpen((o) => !o)}>
        <span className={"ads-select-value" + (selected ? "" : " ads-select-placeholder")}>
          {selected ? selected.label : placeholder}
        </span>
        <span className="ads-select-arrow"><Icon name="down" /></span>
      </div>
      {open ? (
        <div className="ads-select-dropdown">
          {norm.map((o) => {
            const sel = o.value === val;
            const ocls = ["ads-select-option", sel && "ads-select-option--selected", o.disabled && "ads-select-option--disabled"].filter(Boolean).join(" ");
            return (
              <div key={o.value} className={ocls} onClick={() => pick(o)}>
                <span>{o.label}</span>
                {sel ? <span className="ads-select-check"><Icon name="check" /></span> : null}
              </div>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}
