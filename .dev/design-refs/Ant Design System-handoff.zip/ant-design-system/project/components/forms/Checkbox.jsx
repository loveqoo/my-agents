import React from "react";
import { Icon } from "../core/Icon.jsx";

const CSS = `
.ads-check { display: inline-flex; align-items: center; gap: 8px; font-family: var(--font-family);
  font-size: 14px; color: var(--color-text); cursor: pointer; user-select: none; }
.ads-check--disabled { color: var(--color-text-disabled); cursor: not-allowed; }
.ads-check-box { position: relative; width: 16px; height: 16px; border: 1px solid var(--color-border);
  border-radius: var(--radius-sm); background: var(--color-bg-container); transition: all .2s;
  display: inline-flex; align-items: center; justify-content: center; flex: none; }
.ads-check:hover .ads-check-box { border-color: var(--color-primary); }
.ads-check--checked .ads-check-box, .ads-check--indeterminate .ads-check-box {
  background: var(--color-primary); border-color: var(--color-primary); }
.ads-check-box svg { width: 12px; height: 12px; color: #fff; opacity: 0; transition: opacity .1s; }
.ads-check--checked .ads-check-box svg { opacity: 1; }
.ads-check-ind { width: 8px; height: 8px; background: #fff; border-radius: 1px; opacity: 0; }
.ads-check--indeterminate .ads-check-ind { opacity: 1; }
.ads-check--disabled .ads-check-box { background: var(--gray-3); border-color: var(--color-border); }
.ads-check--disabled.ads-check--checked .ads-check-box { background: var(--gray-3); }
.ads-check--disabled.ads-check--checked .ads-check-box svg { color: var(--color-text-disabled); }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "checkbox");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Checkbox({
  checked,
  defaultChecked = false,
  indeterminate = false,
  disabled = false,
  onChange,
  children,
  className = "",
  ...rest
}) {
  inject();
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(defaultChecked);
  const on = isControlled ? checked : internal;

  const toggle = () => {
    if (disabled) return;
    const next = !on;
    if (!isControlled) setInternal(next);
    onChange && onChange({ target: { checked: next } });
  };

  const cls = [
    "ads-check",
    on && "ads-check--checked",
    indeterminate && !on && "ads-check--indeterminate",
    disabled && "ads-check--disabled",
    className,
  ].filter(Boolean).join(" ");

  return (
    <label className={cls} onClick={toggle} {...rest}>
      <span className="ads-check-box">
        {indeterminate && !on ? <span className="ads-check-ind" /> : <Icon name="check" />}
      </span>
      {children != null ? <span>{children}</span> : null}
    </label>
  );
}
