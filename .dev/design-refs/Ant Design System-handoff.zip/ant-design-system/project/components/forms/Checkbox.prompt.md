**Checkbox** — select one or more options from a set, or a single boolean opt-in (terms, remember-me).

```jsx
<Checkbox defaultChecked>I agree</Checkbox>
<Checkbox indeterminate>Select all</Checkbox>
<Checkbox disabled>Unavailable</Checkbox>
```

`onChange(e)` exposes `e.target.checked`. Use `indeterminate` for a parent whose children are partially selected.
