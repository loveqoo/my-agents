import * as React from "react";

export interface RadioProps {
  checked?: boolean;
  disabled?: boolean;
  onChange?: () => void;
  children?: React.ReactNode;
  className?: string;
}

export interface RadioOption {
  label: React.ReactNode;
  value: string | number;
  disabled?: boolean;
}

export interface RadioGroupProps {
  /** Options as strings or {label,value,disabled}. */
  options?: Array<string | RadioOption>;
  value?: string | number;
  defaultValue?: string | number;
  onChange?: (value: string | number) => void;
  /** "default" dots or "button" segmented pills. */
  optionType?: "default" | "button";
  disabled?: boolean;
  className?: string;
}

/** A single radio dot — usually rendered via RadioGroup. */
export function Radio(props: RadioProps): JSX.Element;

/**
 * Ant Design radio group — pick exactly one option. Render as dots or a segmented button bar.
 */
export function RadioGroup(props: RadioGroupProps): JSX.Element;
