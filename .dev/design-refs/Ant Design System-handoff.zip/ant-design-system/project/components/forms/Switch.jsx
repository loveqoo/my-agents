import React from "react";
import { Icon } from "../core/Icon.jsx";

const CSS = `
.ads-switch { position: relative; display: inline-flex; align-items: center; box-sizing: border-box;
  min-width: 44px; height: 22px; padding: 0; border: 0; border-radius: 100px; cursor: pointer;
  background: rgba(0,0,0,.25); transition: background .2s; vertical-align: middle; user-select: none; }
.ads-switch--sm { min-width: 28px; height: 16px; }
.ads-switch--checked { background: var(--color-primary); }
.ads-switch--disabled { opacity: .65; cursor: not-allowed; }
.ads-switch-handle { position: absolute; top: 2px; left: 2px; width: 18px; height: 18px;
  background: #fff; border-radius: 50%; transition: left .2s, width .2s;
  box-shadow: 0 2px 4px rgba(0,35,11,.2); }
.ads-switch--sm .ads-switch-handle { width: 12px; height: 12px; }
.ads-switch--checked .ads-switch-handle { left: calc(100% - 20px); }
.ads-switch--sm.ads-switch--checked .ads-switch-handle { left: calc(100% - 14px); }
.ads-switch-inner { color: #fff; font-size: 12px; margin: 0 7px 0 25px; line-height: 22px;
  transition: margin .2s; }
.ads-switch--checked .ads-switch-inner { margin: 0 25px 0 9px; }
.ads-switch--sm .ads-switch-inner { font-size: 11px; margin: 0 5px 0 18px; line-height: 16px; }
.ads-switch--sm.ads-switch--checked .ads-switch-inner { margin: 0 18px 0 6px; }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "switch");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Switch({
  checked,
  defaultChecked = false,
  disabled = false,
  size = "default",
  checkedChildren,
  unCheckedChildren,
  onChange,
  className = "",
  ...rest
}) {
  inject();
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(defaultChecked);
  const on = isControlled ? checked : internal;

  const toggle = () => {
    if (disabled) return;
    const next = !on;
    if (!isControlled) setInternal(next);
    onChange && onChange(next);
  };

  const cls = [
    "ads-switch",
    on && "ads-switch--checked",
    size === "small" && "ads-switch--sm",
    disabled && "ads-switch--disabled",
    className,
  ].filter(Boolean).join(" ");

  const label = on ? checkedChildren : unCheckedChildren;

  return (
    <button type="button" role="switch" aria-checked={on} className={cls} disabled={disabled} onClick={toggle} {...rest}>
      {label != null ? <span className="ads-switch-inner">{label}</span> : null}
      <span className="ads-switch-handle" />
    </button>
  );
}
