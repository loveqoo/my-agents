import React from "react";

const CSS = `
.ads-radio-group { display: inline-flex; flex-wrap: wrap; gap: 8px 16px; }
.ads-radio { display: inline-flex; align-items: center; gap: 8px; font-family: var(--font-family);
  font-size: 14px; color: var(--color-text); cursor: pointer; user-select: none; }
.ads-radio--disabled { color: var(--color-text-disabled); cursor: not-allowed; }
.ads-radio-dot { position: relative; width: 16px; height: 16px; border: 1px solid var(--color-border);
  border-radius: 50%; background: var(--color-bg-container); transition: all .2s; flex: none; }
.ads-radio:hover .ads-radio-dot { border-color: var(--color-primary); }
.ads-radio--checked .ads-radio-dot { border-color: var(--color-primary); }
.ads-radio-dot::after { content: ""; position: absolute; inset: 0; margin: auto; width: 8px; height: 8px;
  border-radius: 50%; background: var(--color-primary); transform: scale(0); transition: transform .2s; }
.ads-radio--checked .ads-radio-dot::after { transform: scale(1); }
.ads-radio--disabled .ads-radio-dot { background: var(--gray-3); border-color: var(--color-border); }
.ads-radio--disabled.ads-radio--checked .ads-radio-dot::after { background: var(--color-text-disabled); }

/* button style */
.ads-radio-group--buttons { gap: 0; }
.ads-radio-btn { display: inline-flex; align-items: center; height: var(--control-height);
  padding: 0 15px; font-family: var(--font-family); font-size: 14px; color: var(--color-text);
  background: var(--color-bg-container); border: 1px solid var(--color-border); border-left-width: 0;
  cursor: pointer; transition: all .2s; }
.ads-radio-btn:first-child { border-left-width: 1px; border-radius: var(--radius) 0 0 var(--radius); }
.ads-radio-btn:last-child { border-radius: 0 var(--radius) var(--radius) 0; }
.ads-radio-btn:hover { color: var(--color-primary); }
.ads-radio-btn--checked { color: #fff; background: var(--color-primary); border-color: var(--color-primary); }
.ads-radio-btn--checked:hover { color: #fff; background: var(--color-primary-hover); }
.ads-radio-btn--disabled { color: var(--color-text-disabled); background: var(--gray-3); cursor: not-allowed; }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "radio");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Radio({ checked, disabled, onChange, children, className = "", ...rest }) {
  inject();
  const cls = ["ads-radio", checked && "ads-radio--checked", disabled && "ads-radio--disabled", className].filter(Boolean).join(" ");
  return (
    <label className={cls} onClick={() => !disabled && onChange && onChange()} {...rest}>
      <span className="ads-radio-dot" />
      {children != null ? <span>{children}</span> : null}
    </label>
  );
}

export function RadioGroup({
  options = [],
  value,
  defaultValue,
  onChange,
  optionType = "default",
  disabled = false,
  className = "",
  children,
  ...rest
}) {
  inject();
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState(defaultValue);
  const val = isControlled ? value : internal;

  const pick = (v) => {
    if (disabled) return;
    if (!isControlled) setInternal(v);
    onChange && onChange(v);
  };

  const norm = options.map((o) => (typeof o === "object" ? o : { label: o, value: o }));
  const buttons = optionType === "button";

  const cls = ["ads-radio-group", buttons && "ads-radio-group--buttons", className].filter(Boolean).join(" ");

  return (
    <div className={cls} {...rest}>
      {norm.map((o) => {
        const on = o.value === val;
        const dis = disabled || o.disabled;
        if (buttons) {
          const bcls = ["ads-radio-btn", on && "ads-radio-btn--checked", dis && "ads-radio-btn--disabled"].filter(Boolean).join(" ");
          return <span key={o.value} className={bcls} onClick={() => !dis && pick(o.value)}>{o.label}</span>;
        }
        return <Radio key={o.value} checked={on} disabled={dis} onChange={() => pick(o.value)}>{o.label}</Radio>;
      })}
    </div>
  );
}
