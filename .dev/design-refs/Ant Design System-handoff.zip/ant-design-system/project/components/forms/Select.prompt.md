**Select** — pick one option from a dropdown; use when there are more options than fit comfortably as radios.

```jsx
<Select defaultValue="jack" style={{ width: 200 }}
  options={[{label:"Jack",value:"jack"},{label:"Lucy",value:"lucy"}]} />
<Select placeholder="Select a person" options={["Tom","Jerry"]} />
```

`onChange(value)` returns the chosen value. Selected option shows a check. Always give it a width.
