import React from "react";
import { Icon } from "../core/Icon.jsx";

/* Ant Design X — Bubble. A single chat message: avatar + content block.
   Faithful to @ant-design/x bubble styles (filled / outlined / shadow /
   borderless variants; round / corner shapes; start / end placement;
   loading dots and typing cursor). */

const CSS = `
.adx-bubble { display: flex; column-gap: 12px; max-width: 100%; font-family: var(--font-family); }
.adx-bubble--start { flex-direction: row; align-self: flex-start; }
.adx-bubble--end { flex-direction: row-reverse; align-self: flex-end; }
.adx-bubble-avatar { flex: none; }
.adx-bubble-body { display: flex; flex-direction: column; max-width: 100%; min-width: 0; gap: 4px; }
.adx-bubble--end .adx-bubble-body { align-items: flex-end; }
.adx-bubble-header { font-size: 12px; color: var(--color-text-tertiary); padding: 0 4px; }
.adx-bubble-content {
  position: relative; box-sizing: border-box; min-width: 0; max-width: 100%;
  padding: 12px 16px; color: var(--color-text); font-size: 14px; line-height: 1.5714;
  word-break: break-word; white-space: pre-wrap; border-radius: 12px;
}
.adx-bubble-content--filled { background: var(--color-fill-secondary); }
.adx-bubble-content--outlined { border: 1px solid var(--color-border-secondary); }
.adx-bubble-content--shadow { box-shadow: var(--box-shadow-tertiary); background: var(--color-bg-container); }
.adx-bubble-content--borderless { background: transparent; padding: 0; }
.adx-bubble-content--round { border-radius: 20px; }
.adx-bubble--start .adx-bubble-content--corner { border-start-start-radius: 2px; }
.adx-bubble--end .adx-bubble-content--corner { border-start-end-radius: 2px; }
.adx-bubble--end .adx-bubble-content--filled { background: var(--color-primary); color: #fff; }

.adx-bubble-footer { display: flex; gap: 2px; padding: 2px; }

.adx-bubble-dot { display: flex; align-items: center; column-gap: 8px; height: 22px; padding: 0 4px; }
.adx-bubble-dot i { width: 5px; height: 5px; border-radius: 50%; background: var(--color-primary);
  display: inline-block; animation: adxLoadingMove 2s infinite linear; }
.adx-bubble-dot i:nth-child(2) { animation-delay: .2s; }
.adx-bubble-dot i:nth-child(3) { animation-delay: .4s; }
@keyframes adxLoadingMove {
  0% { transform: translateY(0) } 10% { transform: translateY(4px) }
  20% { transform: translateY(0) } 30% { transform: translateY(-4px) } 40% { transform: translateY(0) }
}
.adx-bubble-typing::after {
  content: "|"; font-weight: 900; user-select: none; margin-inline-start: .1em;
  animation: adxCursorBlink .8s infinite linear;
}
@keyframes adxCursorBlink { 0%,100% { opacity: 1 } 50% { opacity: 0 } }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-adx", "bubble");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Bubble({
  placement = "start",
  avatar,
  header,
  content,
  children,
  variant = "filled",
  shape = "default",
  loading = false,
  typing = false,
  footer,
  className = "",
  style,
  ...rest
}) {
  inject();
  const body = content != null ? content : children;
  const contentCls = [
    "adx-bubble-content",
    `adx-bubble-content--${variant}`,
    shape !== "default" && `adx-bubble-content--${shape}`,
    typing && "adx-bubble-typing",
  ].filter(Boolean).join(" ");

  return (
    <div className={`adx-bubble adx-bubble--${placement} ${className}`} style={style} {...rest}>
      {avatar ? <div className="adx-bubble-avatar">{avatar}</div> : null}
      <div className="adx-bubble-body">
        {header ? <div className="adx-bubble-header">{header}</div> : null}
        {loading ? (
          <div className="adx-bubble-content adx-bubble-content--filled">
            <span className="adx-bubble-dot"><i></i><i></i><i></i></span>
          </div>
        ) : (
          <div className={contentCls}>{body}</div>
        )}
        {footer ? <div className="adx-bubble-footer">{footer}</div> : null}
      </div>
    </div>
  );
}

/* Vertical list wrapper with consistent gap. */
export function BubbleList({ children, gap = 16, className = "", style, ...rest }) {
  inject();
  return (
    <div className={"adx-bubble-list " + className}
      style={{ display: "flex", flexDirection: "column", gap, ...style }} {...rest}>
      {children}
    </div>
  );
}
