**Sender** — the AI chat composer. Auto-growing textarea in a 12px rounded card; **Enter** submits, **Shift+Enter** adds a newline; the circular send button becomes a **stop** button while `loading`.

```jsx
<Sender placeholder="Ask me anything…" onSubmit={(text) => send(text)} />

<Sender loading onCancel={stop} />   {/* generating → stop button */}

<Sender
  prefix={<Button type="text" iconName="paper-clip" />}
  actions={<Button type="text" iconName="audio" />}
  footer={<span style={{fontSize:12,color:"var(--color-text-tertiary)"}}>Enter to send</span>}
  onSubmit={send}
/>
```

Controlled via `value`/`onChange` or uncontrolled. Send is disabled while empty.
