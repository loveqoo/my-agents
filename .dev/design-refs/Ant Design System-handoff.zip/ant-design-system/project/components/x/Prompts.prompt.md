**Prompts** — tappable suggestion cards that seed a conversation (starter questions, quick actions). Horizontal scrolling row by default.

```jsx
<Prompts
  title="✨ Try one of these"
  items={[
    { key: "1", icon: "bulb", iconColor: "var(--gold-6)", label: "Ignite ideas", description: "Brainstorm product names" },
    { key: "2", icon: "fire", iconColor: "var(--volcano-6)", label: "What's hot", description: "Trending in AI this week" },
    { key: "3", icon: "read", iconColor: "var(--green-6)", label: "Explain", description: "Summarize a long doc" },
  ]}
  onItemClick={(it) => ask(it.label)}
/>
```

Use `wrap` to flow onto multiple lines or `vertical` for a stacked list.
