import React from "react";
import { Icon } from "../core/Icon.jsx";

/* Ant Design X — Sender. The chat composer: a 12px rounded container with a
   borderless textarea, optional prefix/header, and an actions row whose primary
   control is a circular send button (or a stop button while generating). */

const CSS = `
.adx-sender { position: relative; width: 100%; box-sizing: border-box; font-family: var(--font-family);
  background: var(--color-bg-container); border: 1px solid rgba(0,0,0,.1); border-radius: 12px;
  box-shadow: var(--box-shadow-tertiary); transition: border-color .2s, box-shadow .2s; }
.adx-sender--focused { border-color: var(--color-primary); box-shadow: 0 4px 12px 0 rgba(22,119,255,.1); }
.adx-sender-header { padding: 12px 12px 0; }
.adx-sender-content { display: flex; gap: 8px; width: 100%; padding: 12px; box-sizing: border-box; align-items: flex-end; }
.adx-sender-prefix { flex: none; display: flex; align-items: center; }
.adx-sender-input { flex: auto; align-self: center; border: none; outline: none; resize: none;
  background: transparent; font: inherit; font-size: 14px; line-height: 1.5714; color: var(--color-text);
  padding: 6px 0; max-height: 160px; caret-color: var(--color-primary); }
.adx-sender-input::placeholder { color: var(--color-text-quaternary); }
.adx-sender-actions { flex: none; display: flex; align-items: center; gap: 8px; }

.adx-sender-btn { width: 32px; height: 32px; border-radius: 50%; border: none; cursor: pointer;
  display: inline-flex; align-items: center; justify-content: center; font-size: 16px; transition: all .2s; flex: none; }
.adx-sender-btn--icon { background: transparent; color: var(--color-text-tertiary); }
.adx-sender-btn--icon:hover { background: var(--color-fill-tertiary); color: var(--color-text); }
.adx-sender-send { background: var(--color-primary); color: #fff; }
.adx-sender-send:hover { background: var(--color-primary-hover); }
.adx-sender-send:disabled { background: rgba(22,119,255,.45); color: #fff; cursor: not-allowed; }
.adx-sender-stop { background: var(--color-primary); color: #fff; }
.adx-sender-stop:hover { background: var(--color-primary-hover); }
.adx-sender-footer { padding: 0 12px 12px; }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-adx", "sender");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Sender({
  value,
  defaultValue = "",
  placeholder = "Ask me anything…",
  onChange,
  onSubmit,
  onCancel,
  loading = false,
  disabled = false,
  prefix,
  header,
  footer,
  actions,
  className = "",
  style,
  ...rest
}) {
  inject();
  const [focused, setFocused] = React.useState(false);
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState(defaultValue);
  const val = isControlled ? value : internal;
  const taRef = React.useRef(null);

  const setVal = (v) => { if (!isControlled) setInternal(v); onChange && onChange(v); };

  React.useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 160) + "px";
  }, [val]);

  const submit = () => {
    if (loading || disabled) return;
    const text = (val || "").trim();
    if (!text) return;
    onSubmit && onSubmit(text);
    if (!isControlled) setInternal("");
  };

  const onKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submit(); }
  };

  return (
    <div className={["adx-sender", focused && "adx-sender--focused", className].filter(Boolean).join(" ")} style={style} {...rest}>
      {header ? <div className="adx-sender-header">{header}</div> : null}
      <div className="adx-sender-content">
        {prefix ? <div className="adx-sender-prefix">{prefix}</div> : null}
        <textarea
          ref={taRef}
          className="adx-sender-input"
          rows={1}
          placeholder={placeholder}
          value={val}
          disabled={disabled}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={onKeyDown}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
        />
        <div className="adx-sender-actions">
          {actions}
          {loading ? (
            <button className="adx-sender-btn adx-sender-stop" onClick={onCancel} title="Stop">
              <span style={{ width: 11, height: 11, background: "#fff", borderRadius: 2, display: "block" }} />
            </button>
          ) : (
            <button className="adx-sender-btn adx-sender-send" onClick={submit} disabled={disabled || !(val || "").trim()} title="Send">
              <Icon name="arrow-up" />
            </button>
          )}
        </div>
      </div>
      {footer ? <div className="adx-sender-footer">{footer}</div> : null}
    </div>
  );
}
