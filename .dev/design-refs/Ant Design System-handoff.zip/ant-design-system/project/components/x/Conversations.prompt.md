**Conversations** — the chat-history sidebar for an AI app: a tinted "new conversation" button over a selectable list of threads, optionally grouped by date.

```jsx
<Conversations
  defaultActiveKey="t1"
  onCreate={newChat}
  onActiveChange={openThread}
  items={[
    { group: "Today", items: [
      { key: "t1", label: "Design system tokens", icon: "message" },
      { key: "t2", label: "Refactor sidebar" },
    ]},
    { group: "Yesterday", items: [
      { key: "t3", label: "Trip to Hangzhou" },
    ]},
  ]}
/>
```

Pass a flat array for an ungrouped list. Each item reveals an `ellipsis` menu on hover (`onMenu`).
