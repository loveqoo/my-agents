import React from "react";
import { Icon } from "../core/Icon.jsx";

/* Ant Design X — Prompts. A row (or wrap / column) of suggestion cards that seed
   the conversation. Each item: optional icon, label (medium) and description. */

const CSS = `
.adx-prompts { max-width: 100%; font-family: var(--font-family); box-sizing: border-box; }
.adx-prompts *, .adx-prompts *::before, .adx-prompts *::after { box-sizing: border-box; }
.adx-prompts-title { margin: 0 0 12px; font-weight: 400; color: var(--color-text-tertiary); font-size: 14px; }
.adx-prompts-list { display: flex; gap: 12px; list-style: none; padding: 0; margin: 0; align-items: stretch;
  overflow-x: auto; scrollbar-width: none; }
.adx-prompts-list::-webkit-scrollbar { display: none; }
.adx-prompts-list--wrap { flex-wrap: wrap; }
.adx-prompts-list--vertical { flex-direction: column; align-items: stretch; }
.adx-prompts-item { flex: none; display: flex; gap: 8px; padding: 12px 16px; align-items: flex-start;
  background: var(--color-bg-container); border-radius: 8px; border: 1px solid var(--color-border-secondary);
  transition: border .3s, background .3s; cursor: pointer; text-align: start; }
.adx-prompts-item:hover { background: var(--color-fill-tertiary); }
.adx-prompts-item:active { background: var(--color-fill); }
.adx-prompts-item--disabled { pointer-events: none; background: var(--gray-3); }
.adx-prompts-icon { font-size: 16px; line-height: 1.5714; flex: none; }
.adx-prompts-content { flex: auto; min-width: 0; display: flex; flex-direction: column; gap: 4px; align-items: flex-start; }
.adx-prompts-label { margin: 0; color: var(--color-text-heading); font-weight: 500; font-size: 14px; line-height: 1.5714; }
.adx-prompts-desc { margin: 0; color: var(--color-text-tertiary); font-size: 14px; line-height: 1.5714; }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-adx", "prompts");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Prompts({
  title,
  items = [],
  onItemClick,
  wrap = false,
  vertical = false,
  className = "",
  style,
  ...rest
}) {
  inject();
  const listCls = [
    "adx-prompts-list",
    wrap && "adx-prompts-list--wrap",
    vertical && "adx-prompts-list--vertical",
  ].filter(Boolean).join(" ");

  return (
    <div className={"adx-prompts " + className} style={style} {...rest}>
      {title ? <h5 className="adx-prompts-title">{title}</h5> : null}
      <ul className={listCls}>
        {items.map((it) => (
          <li
            key={it.key}
            className={"adx-prompts-item" + (it.disabled ? " adx-prompts-item--disabled" : "")}
            style={it.style}
            onClick={() => !it.disabled && onItemClick && onItemClick(it)}
          >
            {it.icon ? (
              <span className="adx-prompts-icon" style={{ color: it.iconColor }}>
                {typeof it.icon === "string" ? <Icon name={it.icon} /> : it.icon}
              </span>
            ) : null}
            <div className="adx-prompts-content">
              {it.label ? <h6 className="adx-prompts-label">{it.label}</h6> : null}
              {it.description ? <p className="adx-prompts-desc">{it.description}</p> : null}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
