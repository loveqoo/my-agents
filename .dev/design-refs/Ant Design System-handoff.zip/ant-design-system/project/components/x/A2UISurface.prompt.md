**A2UISurface** — renders the **A2UI (Agent-to-User Interface)** protocol: an agent streams declarative JSON commands describing a UI, and this component renders them into native design-system components. Use it for *generative UI* — when the agent should reply with an interactive form/card instead of plain text.

```jsx
const messages = [
  { createSurface: { surfaceId: "booking" } },
  { updateComponents: { root: "root", components: [
    { id: "root", componentType: "Card", title: "Book a table", children: ["form","submit"] },
    { id: "form", componentType: "Column", children: ["date","guests"] },
    { id: "date", componentType: "Field", label: "Date",
      children: ["dateInput"] },
    { id: "dateInput", componentType: "DateField", value: { path: "/form/date" } },
    { id: "guests", componentType: "Field", label: "Guests",
      children: ["guestSel"] },
    { id: "guestSel", componentType: "Select", value: { path: "/form/guests" },
      options: [{label:"2",value:2},{label:"4",value:4}] },
    { id: "submit", componentType: "Button", label: "Confirm",
      action: { name: "confirmBooking" } },
  ]}},
  { updateDataModel: { contents: [{ op: "add", path: "/form/guests", value: 2 }] } },
];

<A2UISurface messages={messages}
  onAction={(action, data) => sendToAgent(action.name, data)} />
```

**Data binding:** any prop can be a literal or a binding `{ path: "/form/date" }`; interactive controls (`TextField`, `DateField`, `Select`, `Checkbox`) two-way bind to their `value` path. **Actions:** a `Button`'s `action` fires `onAction(action, dataModel)` back to the agent.

**Extensible catalog (the key part):** built-in types are `Column`, `Row`, `Text`, `Heading`, `Divider`, `Image`, `Tag`, `Card`, `Field`, `TextField`, `DateField`, `Select`, `Checkbox`, `Button`. Register your own at runtime:

```jsx
registerA2UIComponent("RatingStars", (node, ctx) => <Stars value={ctx.get(node.props.value.path)} onChange={v => ctx.set(node.props.value.path, v)} />);
```

or pass per-instance overrides via the `catalog` prop. Supports A2UI v0.8 (implicit surface) and v0.9 (explicit `createSurface`). Unknown component types render a visible warning rather than crashing (fault-tolerant, per the protocol).
