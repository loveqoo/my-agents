import * as React from "react";

export interface ConversationItem {
  key: string;
  label: React.ReactNode;
  /** Ant icon name or node. Defaults to a message glyph. */
  icon?: string | React.ReactNode;
  onMenu?: (item: ConversationItem) => void;
}

export interface ConversationGroup {
  group: string;
  items: ConversationItem[];
}

export interface ConversationsProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Flat item list, or grouped as [{group, items}]. */
  items: ConversationItem[] | ConversationGroup[];
  activeKey?: string;
  defaultActiveKey?: string;
  onActiveChange?: (key: string) => void;
  /** Fires when the creation button is clicked. */
  onCreate?: () => void;
  creationLabel?: string;
  /** Show the "new conversation" button. @default true */
  showCreation?: boolean;
}

/**
 * Ant Design X conversations — the chat-history sidebar. A tinted "new
 * conversation" button over a selectable list of past threads, optionally grouped
 * by date. Each row reveals a menu affordance on hover.
 */
export function Conversations(props: ConversationsProps): JSX.Element;
