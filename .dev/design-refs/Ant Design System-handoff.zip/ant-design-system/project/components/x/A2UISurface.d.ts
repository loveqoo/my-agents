import * as React from "react";

/** A single A2UI command in the agent's stream. */
export interface A2UIMessage {
  createSurface?: { surfaceId: string };
  updateComponents?: {
    root?: string;
    components: Array<{
      id: string;
      componentType: string;
      children?: string[];
      [prop: string]: any;
    }>;
  };
  updateDataModel?: {
    surfaceId?: string;
    contents: Array<{ op: "add" | "replace" | "remove"; path: string; value?: any }>;
  };
}

/** A property value bound to the data model by JSON-pointer path. */
export interface A2UIBinding { path: string }

/** Render context passed to every catalog renderer. */
export interface A2UIContext {
  /** Resolve a literal-or-binding property value against the data model. */
  resolve: (value: any) => any;
  /** Read a path from the data model. */
  get: (path: string) => any;
  /** Write a path into the data model (two-way binding). */
  set: (path: string, value: any) => void;
  /** Fire an action event back to the agent. */
  dispatch: (action: any) => void;
  /** Render an array of child component ids. */
  render: (ids: string[]) => React.ReactNode;
}

export type A2UIRenderer = (node: { id: string; type: string; props: any; children: string[] }, ctx: A2UIContext) => React.ReactNode;

export interface A2UISurfaceProps {
  /** The agent's A2UI command stream. */
  messages: A2UIMessage[];
  /** Restrict to a specific surface id (optional). */
  surfaceId?: string;
  /** Extra/override component renderers, merged over the default catalog. */
  catalog?: Record<string, A2UIRenderer>;
  /** Fires when an interactive component (e.g. a submit Button) dispatches an action; receives (action, dataModel). */
  onAction?: (action: any, dataModel: any) => void;
  /** Fires whenever the bound data model changes. */
  onDataChange?: (dataModel: any) => void;
  style?: React.CSSProperties;
  className?: string;
}

/** The shared, mutable default catalog (A2UI type → renderer). */
export const a2uiCatalog: Record<string, A2UIRenderer>;

/** Register or override a component type at runtime — the extensibility hook. */
export function registerA2UIComponent(type: string, renderer: A2UIRenderer): void;

/**
 * Ant Design X A2UISurface — renders the A2UI (Agent-to-User Interface) protocol.
 * An agent streams declarative JSON commands describing a UI; this component
 * renders them into native design-system components with path-based data binding,
 * two-way interactive controls, and action events back to the agent.
 *
 * @startingPoint section="AI / X" subtitle="Render agent-generated UI (A2UI protocol) with DS components" viewport="700x420"
 */
export function A2UISurface(props: A2UISurfaceProps): JSX.Element;
