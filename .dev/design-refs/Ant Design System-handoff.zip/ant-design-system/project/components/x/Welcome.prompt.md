**Welcome** — the hero greeting for an empty AI conversation: icon/illustration + title + description.

```jsx
<Welcome
  icon={<img src="../../assets/icons/ant-design.svg" style={{width:48}} />}
  title="Hello, I'm Ant Design X"
  description="Based on Ant Design, AGI product interface solution, creating a better intelligent vision."
  extra={<Button iconName="share-alt" type="text" />}
/>
```

`variant="filled"` puts it on a soft tinted card with a smaller title. Pair with `Prompts` to suggest first actions.
