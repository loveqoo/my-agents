import React from "react";
import { Icon } from "../core/Icon.jsx";

/* Ant Design X — Conversations. The chat-history sidebar: a "new conversation"
   button (tinted primary), optional group titles, and a list of selectable items
   each with an icon, label and a hover affordance for a menu. */

const CSS = `
.adx-convs { display: flex; flex-direction: column; gap: 4px; overflow-y: auto; padding: 12px;
  margin: 0; list-style: none; font-family: var(--font-family); box-sizing: border-box; }
.adx-convs-creation { display: flex; align-items: center; gap: 8px; justify-content: center;
  background: rgba(22,119,255,.15); color: var(--color-primary); border: none; font-weight: 500;
  padding: 8px 12px; font-size: 14px; line-height: 1.5714; cursor: pointer; border-radius: 8px;
  margin-bottom: 12px; transition: all .2s; }
.adx-convs-creation:hover { background: rgba(22,119,255,.25); }
.adx-convs-group-title { display: flex; align-items: center; color: var(--color-text-description);
  height: 40px; padding: 0 8px; font-size: 12px; }
.adx-convs-list { display: flex; flex-direction: column; gap: 4px; }
.adx-convs-item { display: flex; align-items: center; gap: 8px; height: 40px; min-height: 40px;
  padding: 0 8px; border-radius: 8px; cursor: pointer; transition: all .2s; color: var(--color-text); }
.adx-convs-item:hover { background: var(--color-fill-tertiary); }
.adx-convs-item--active { background: var(--color-fill-secondary); }
.adx-convs-icon { flex: none; font-size: 16px; color: var(--color-text-secondary); display: inline-flex; }
.adx-convs-label { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 14px; }
.adx-convs-menu { opacity: 0; font-size: 16px; color: var(--color-text-tertiary); display: inline-flex; transition: opacity .2s; }
.adx-convs-item:hover .adx-convs-menu, .adx-convs-item--active .adx-convs-menu { opacity: .6; }
.adx-convs-menu:hover { opacity: 1 !important; }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-adx", "conversations");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Conversations({
  items = [],
  activeKey,
  defaultActiveKey,
  onActiveChange,
  onCreate,
  creationLabel = "New conversation",
  showCreation = true,
  className = "",
  style,
  ...rest
}) {
  inject();
  const isControlled = activeKey !== undefined;
  const [internal, setInternal] = React.useState(defaultActiveKey);
  const active = isControlled ? activeKey : internal;

  const pick = (k) => { if (!isControlled) setInternal(k); onActiveChange && onActiveChange(k); };

  // Support a flat list or [{group, items}] groups
  const groups = items.length && items[0] && items[0].items
    ? items
    : [{ items }];

  return (
    <div className={"adx-convs " + className} style={style} {...rest}>
      {showCreation ? (
        <button className="adx-convs-creation" onClick={onCreate}>
          <Icon name="plus" /> {creationLabel}
        </button>
      ) : null}
      {groups.map((g, gi) => (
        <React.Fragment key={g.group || gi}>
          {g.group ? <div className="adx-convs-group-title">{g.group}</div> : null}
          <div className="adx-convs-list">
            {g.items.map((it) => (
              <div
                key={it.key}
                className={"adx-convs-item" + (it.key === active ? " adx-convs-item--active" : "")}
                onClick={() => pick(it.key)}
              >
                <span className="adx-convs-icon">
                  {it.icon ? (typeof it.icon === "string" ? <Icon name={it.icon} /> : it.icon) : <Icon name="message" />}
                </span>
                <span className="adx-convs-label">{it.label}</span>
                <span className="adx-convs-menu" onClick={(e) => { e.stopPropagation(); it.onMenu && it.onMenu(it); }}>
                  <Icon name="ellipsis" />
                </span>
              </div>
            ))}
          </div>
        </React.Fragment>
      ))}
    </div>
  );
}
