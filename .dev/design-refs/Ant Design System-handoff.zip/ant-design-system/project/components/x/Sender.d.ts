import * as React from "react";

export interface SenderProps {
  value?: string;
  defaultValue?: string;
  placeholder?: string;
  onChange?: (value: string) => void;
  /** Fires with the trimmed text on Enter or send-button click. */
  onSubmit?: (value: string) => void;
  /** Fires when the stop button is clicked while `loading`. */
  onCancel?: () => void;
  /** Generating state — swaps the send button for a stop button. */
  loading?: boolean;
  disabled?: boolean;
  /** Leading node inside the box (e.g. an attach button). */
  prefix?: React.ReactNode;
  /** Content above the input row (e.g. attachment chips). */
  header?: React.ReactNode;
  /** Content below the input row (hint text, token count). */
  footer?: React.ReactNode;
  /** Extra action buttons placed before the send button. */
  actions?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Ant Design X sender — the chat composer. Auto-growing borderless textarea in a
 * rounded card; Enter submits, Shift+Enter newlines; circular send button turns
 * into a stop button while `loading`.
 *
 * @startingPoint section="AI / X" subtitle="AI chat composer with auto-grow, attach and send/stop" viewport="700x140"
 */
export function Sender(props: SenderProps): JSX.Element;
