**Bubble / BubbleList** — a single chat message and a spaced stack of them; the core atom of an Ant Design X AI conversation.

```jsx
<Bubble placement="start" avatar={<Avatar style={{background:"var(--color-primary)"}}><Icon name="robot"/></Avatar>}
  header="Assistant" content="How can I help you today?" />

<Bubble placement="end" variant="filled" content="Summarize this thread." />

<Bubble placement="start" loading />        {/* thinking dots */}
<Bubble placement="start" typing content="Streaming reply" />  {/* blinking cursor */}

<BubbleList gap={20}>…</BubbleList>
```

Variants: `filled` (default soft fill; an `end` filled bubble becomes brand-blue/white for the user), `outlined`, `shadow`, `borderless`. Shapes: `default`, `round`, `corner` (speech-notch). Put copy/retry/like buttons in `footer`.
