import * as React from "react";

export interface BubbleProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Side the message sits on. "start" = incoming (AI), "end" = outgoing (user). @default "start" */
  placement?: "start" | "end";
  /** Avatar node shown beside the bubble. */
  avatar?: React.ReactNode;
  /** Small label above the bubble (name / role / time). */
  header?: React.ReactNode;
  /** Message body (alias of children). */
  content?: React.ReactNode;
  /** Bubble surface treatment. @default "filled" */
  variant?: "filled" | "outlined" | "shadow" | "borderless";
  /** Corner style: rounded box, fully round, or one sharp speech-notch corner. @default "default" */
  shape?: "default" | "round" | "corner";
  /** Show the three-dot thinking animation instead of content. */
  loading?: boolean;
  /** Append a blinking typing cursor to the content. */
  typing?: boolean;
  /** Action row under the bubble (copy / retry / like …). */
  footer?: React.ReactNode;
  children?: React.ReactNode;
}

export interface BubbleListProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Vertical gap between bubbles in px. @default 16 */
  gap?: number;
  children?: React.ReactNode;
}

/**
 * Ant Design X bubble — one message in a conversation. The core building block of
 * an AI chat: avatar, optional header, a variant-styled content block, and a footer
 * action row. Use placement="end" + variant="filled" for the user's own messages.
 *
 * @startingPoint section="AI / X" subtitle="Chat message bubble with avatar, variants and footer actions" viewport="700x300"
 */
export function Bubble(props: BubbleProps): JSX.Element;

/** Vertical stack of Bubbles with even spacing. */
export function BubbleList(props: BubbleListProps): JSX.Element;
