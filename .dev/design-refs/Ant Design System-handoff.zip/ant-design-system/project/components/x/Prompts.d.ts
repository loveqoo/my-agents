import * as React from "react";

export interface PromptItem {
  key: string;
  /** Ant icon name or a custom node. */
  icon?: string | React.ReactNode;
  /** Color for a string icon. */
  iconColor?: string;
  label?: React.ReactNode;
  description?: React.ReactNode;
  disabled?: boolean;
  style?: React.CSSProperties;
}

export interface PromptsProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Optional heading above the list. */
  title?: React.ReactNode;
  items: PromptItem[];
  onItemClick?: (item: PromptItem) => void;
  /** Allow the row to wrap onto multiple lines. */
  wrap?: boolean;
  /** Stack items vertically instead of a horizontal row. */
  vertical?: boolean;
}

/**
 * Ant Design X prompts — tappable suggestion cards that seed a conversation
 * (starter questions, quick actions). Horizontal row by default; `wrap` or
 * `vertical` for other layouts.
 *
 * @startingPoint section="AI / X" subtitle="Suggestion cards to seed an AI conversation" viewport="700x180"
 */
export function Prompts(props: PromptsProps): JSX.Element;
