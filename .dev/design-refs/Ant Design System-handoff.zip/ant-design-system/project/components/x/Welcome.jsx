import React from "react";

/* Ant Design X — Welcome. Hero greeting for an empty chat: icon, title, subtitle,
   optional extra. "filled" sits on a soft tinted card; "borderless" is bare. */

const CSS = `
.adx-welcome { display: flex; gap: 16px; align-items: flex-start; font-family: var(--font-family); }
.adx-welcome--filled { padding: 12px 16px; background: var(--color-fill-secondary); border-radius: 8px; }
.adx-welcome-icon { flex: none; display: flex; }
.adx-welcome-icon img { height: 100%; }
.adx-welcome-body { display: flex; flex-direction: column; gap: 8px; flex: auto; min-width: 0; }
.adx-welcome-titles { display: flex; gap: 8px; align-items: center; }
.adx-welcome-title { margin: 0; font-size: 24px; line-height: 1.33; font-weight: 600; color: var(--color-text-heading); }
.adx-welcome--filled .adx-welcome-title { font-size: 18px; }
.adx-welcome-extra { margin-inline-start: auto; }
.adx-welcome-desc { margin: 0; color: var(--color-text-secondary); font-size: 14px; line-height: 1.5714; }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-adx", "welcome");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Welcome({
  icon,
  title,
  description,
  extra,
  variant = "borderless",
  className = "",
  style,
  ...rest
}) {
  inject();
  return (
    <div className={`adx-welcome adx-welcome--${variant} ${className}`} style={style} {...rest}>
      {icon ? <div className="adx-welcome-icon">{icon}</div> : null}
      <div className="adx-welcome-body">
        <div className="adx-welcome-titles">
          <h2 className="adx-welcome-title">{title}</h2>
          {extra ? <div className="adx-welcome-extra">{extra}</div> : null}
        </div>
        {description ? <p className="adx-welcome-desc">{description}</p> : null}
      </div>
    </div>
  );
}
