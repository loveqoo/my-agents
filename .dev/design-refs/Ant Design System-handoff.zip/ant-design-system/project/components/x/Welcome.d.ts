import * as React from "react";

export interface WelcomeProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Leading illustration / logo / icon node. */
  icon?: React.ReactNode;
  /** Greeting headline. */
  title: React.ReactNode;
  /** Supporting line(s) under the title. */
  description?: React.ReactNode;
  /** Top-right node (e.g. a help button). */
  extra?: React.ReactNode;
  /** "borderless" bare hero, or "filled" soft tinted card. @default "borderless" */
  variant?: "borderless" | "filled";
}

/**
 * Ant Design X welcome — the hero greeting shown in an empty conversation, pairing
 * a logo/illustration with a title and description.
 */
export function Welcome(props: WelcomeProps): JSX.Element;
