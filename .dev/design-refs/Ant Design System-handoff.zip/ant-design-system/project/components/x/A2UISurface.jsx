import React from "react";
import { Button } from "../forms/Button.jsx";
import { Input } from "../forms/Input.jsx";
import { Select } from "../forms/Select.jsx";
import { Checkbox } from "../forms/Checkbox.jsx";
import { Card } from "../data/Card.jsx";
import { Tag } from "../data/Tag.jsx";
import { Icon } from "../core/Icon.jsx";

/* ============================================================
   Ant Design X — A2UISurface
   A renderer for the A2UI (Agent-to-User Interface) protocol: an
   agent streams declarative JSON commands describing a UI, and this
   component renders them into native design-system components.

   - Flat component list (adjacency model, children referenced by id)
   - Path-based data binding ( { path: "/form/name" } ) with two-way
     updates from interactive controls
   - Action events bubble back to the agent via onAction
   - Extensible Catalog: register custom component types at runtime

   Commands handled (A2UI v0.8 / v0.9 core):
     createSurface    { surfaceId }
     updateComponents { components: [ { id, componentType, ...props, children:[ids] } ], root? }
     updateDataModel  { contents: [ { op:"add"|"replace"|"remove", path, value } ] }
   ============================================================ */

/* ---------- data-model helpers (JSON-pointer-ish paths) ---------- */
function getPath(model, path) {
  if (!path) return undefined;
  const parts = String(path).split("/").filter(Boolean);
  let cur = model;
  for (const p of parts) { if (cur == null) return undefined; cur = cur[p]; }
  return cur;
}
function setPath(model, path, value) {
  const parts = String(path).split("/").filter(Boolean);
  const next = Array.isArray(model) ? model.slice() : { ...(model || {}) };
  let cur = next;
  for (let i = 0; i < parts.length - 1; i++) {
    const k = parts[i];
    cur[k] = cur[k] && typeof cur[k] === "object" ? (Array.isArray(cur[k]) ? cur[k].slice() : { ...cur[k] }) : {};
    cur = cur[k];
  }
  cur[parts[parts.length - 1]] = value;
  return next;
}
function isBinding(v) { return v && typeof v === "object" && typeof v.path === "string" && Object.keys(v).length === 1; }

/* ---------- build structure from a command stream ---------- */
function buildFromMessages(messages, wantSurface) {
  const components = {};
  let data = {};
  let rootId = null;
  let surfaceId = wantSurface || null;
  for (const msg of messages || []) {
    if (msg.createSurface) {
      surfaceId = surfaceId || msg.createSurface.surfaceId;
    }
    if (msg.updateComponents) {
      const uc = msg.updateComponents;
      (uc.components || []).forEach((c) => {
        const { id, componentType, component, children, properties, ...rest } = c;
        const type = componentType || (component && component.componentType);
        const props = properties || (component && component.properties) || rest;
        const kids = children || (component && component.children) || [];
        components[id] = { id, type, props: props || {}, children: kids };
      });
      if (uc.root) rootId = uc.root;
    }
    if (msg.updateDataModel) {
      (msg.updateDataModel.contents || []).forEach((op) => {
        if (op.op === "remove") {
          const cur = getPath(data, op.path);
          if (cur !== undefined) data = setPath(data, op.path, undefined);
        } else {
          data = setPath(data, op.path, op.value);
        }
      });
    }
  }
  if (!rootId) {
    rootId = components.root ? "root" : Object.keys(components)[0] || null;
  }
  return { components, data, rootId, surfaceId };
}

/* ---------- default catalog: A2UI type → DS component ---------- */
export const a2uiCatalog = {
  Column: (n, ctx) => (
    <div style={{ display: "flex", flexDirection: "column", gap: n.props.gap != null ? n.props.gap : 12, ...n.props.style }}>
      {ctx.render(n.children)}
    </div>
  ),
  Row: (n, ctx) => (
    <div style={{ display: "flex", flexDirection: "row", alignItems: n.props.align || "center", gap: n.props.gap != null ? n.props.gap : 12, flexWrap: n.props.wrap ? "wrap" : "nowrap", ...n.props.style }}>
      {ctx.render(n.children)}
    </div>
  ),
  Text: (n, ctx) => {
    const v = n.props.variant;
    const map = {
      heading: { fontSize: 18, fontWeight: 600, color: "var(--color-text-heading)" },
      title: { fontSize: 16, fontWeight: 600, color: "var(--color-text-heading)" },
      caption: { fontSize: 12, color: "var(--color-text-tertiary)" },
      body: { fontSize: 14, color: "var(--color-text)" },
    };
    return <div style={{ lineHeight: 1.5, ...(map[v] || map.body), ...n.props.style }}>{ctx.resolve(n.props.text)}</div>;
  },
  Divider: () => <div style={{ height: 1, background: "var(--color-border-secondary)", margin: "4px 0" }} />,
  Image: (n, ctx) => (
    <img src={ctx.resolve(n.props.src)} alt={ctx.resolve(n.props.alt) || ""} style={{ maxWidth: "100%", borderRadius: "var(--radius)", display: "block", ...n.props.style }} />
  ),
  Tag: (n, ctx) => <Tag color={n.props.color}>{ctx.resolve(n.props.label)}</Tag>,
  Card: (n, ctx) => (
    <Card title={ctx.resolve(n.props.title)} size={n.props.size || "small"} style={n.props.style}>
      {ctx.render(n.children)}
    </Card>
  ),
  Field: (n, ctx) => (
    <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <span style={{ fontSize: 13, color: "var(--color-text-secondary)" }}>{ctx.resolve(n.props.label)}</span>
      {ctx.render(n.children)}
    </label>
  ),
  TextField: (n, ctx) => {
    const path = n.props.value && n.props.value.path;
    return <Input placeholder={ctx.resolve(n.props.placeholder)} value={path ? (ctx.get(path) ?? "") : undefined}
      onChange={(e) => path && ctx.set(path, e.target.value)} />;
  },
  DateField: (n, ctx) => {
    const path = n.props.value && n.props.value.path;
    return <Input type="date" value={path ? (ctx.get(path) ?? "") : undefined}
      onChange={(e) => path && ctx.set(path, e.target.value)} />;
  },
  Select: (n, ctx) => {
    const path = n.props.value && n.props.value.path;
    return <Select options={ctx.resolve(n.props.options) || []} placeholder={ctx.resolve(n.props.placeholder)}
      value={path ? ctx.get(path) : undefined} onChange={(v) => path && ctx.set(path, v)} />;
  },
  Checkbox: (n, ctx) => {
    const path = n.props.value && n.props.value.path;
    return <Checkbox checked={path ? !!ctx.get(path) : false} onChange={(e) => path && ctx.set(path, e.target.checked)}>
      {ctx.resolve(n.props.label)}
    </Checkbox>;
  },
  Button: (n, ctx) => (
    <Button type={n.props.variant || "primary"} block={n.props.block} iconName={n.props.icon}
      danger={n.props.danger} onClick={() => ctx.dispatch(n.props.action || { name: n.id })}>
      {ctx.resolve(n.props.label)}
    </Button>
  ),
};

/* Register/override a component type at runtime (extensibility hook). */
export function registerA2UIComponent(type, renderer) { a2uiCatalog[type] = renderer; }

/* ---------- the surface renderer ---------- */
export function A2UISurface({ messages = [], surfaceId, catalog, onAction, onDataChange, style, className }) {
  const merged = React.useMemo(() => ({ ...a2uiCatalog, ...(catalog || {}) }), [catalog]);
  const built = React.useMemo(() => buildFromMessages(messages, surfaceId), [messages, surfaceId]);
  const [data, setData] = React.useState(built.data);
  React.useEffect(() => { setData(built.data); }, [built]);

  const ctx = {
    resolve: (v) => (isBinding(v) ? getPath(data, v.path) : v),
    get: (path) => getPath(data, path),
    set: (path, value) => setData((d) => { const nd = setPath(d, path, value); onDataChange && onDataChange(nd); return nd; }),
    dispatch: (action) => onAction && onAction(action, data),
    render: (ids) => (ids || []).map((id) => renderNode(built.components[id])),
  };
  function renderNode(node) {
    if (!node) return null;
    const r = merged[node.type];
    if (!r) return <div key={node.id} style={{ color: "var(--color-error)", fontSize: 12 }}>⚠ Unknown A2UI component: {String(node.type)}</div>;
    return <React.Fragment key={node.id}>{r(node, ctx)}</React.Fragment>;
  }

  if (!built.rootId) return null;
  return <div className={className} style={{ fontFamily: "var(--font-family)", ...style }}>{renderNode(built.components[built.rootId])}</div>;
}
