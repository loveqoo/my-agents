**Avatar / AvatarGroup** — represent a user or entity with an image, initials, or icon.

```jsx
<Avatar src="/u/jane.jpg" />
<Avatar style={{ background: "var(--color-primary)" }}>U</Avatar>
<Avatar shape="square" size="large">AD</Avatar>
<AvatarGroup>
  <Avatar src="a.jpg" /><Avatar src="b.jpg" /><Avatar>+3</Avatar>
</AvatarGroup>
```

Sizes: small 24 / default 32 / large 40, or a pixel number. Set `background` via style for initials.
