**Card** — a bordered surface that groups related content. Optional header (`title`/`extra`), `cover` media, and footer `actions`.

```jsx
<Card title="Account" extra={<a>More</a>}>
  <p>Card content</p>
</Card>

<Card hoverable cover={<img src="/banner.jpg" />}
  actions={[<Icon name="setting" />, <Icon name="edit" />, <Icon name="ellipsis" />]}>
  Body
</Card>
```

Use `size="small"` for dense lists, `hoverable` for clickable cards in a grid, `bordered={false}` on colored backgrounds.
