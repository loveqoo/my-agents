import * as React from "react";

/**
 * Props for the Ant Design card.
 *
 * @startingPoint section="Surfaces" subtitle="Content card with header, body and actions" viewport="700x360"
 */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Header title. Omit for a headless card. */
  title?: React.ReactNode;
  /** Top-right header content (link or action). */
  extra?: React.ReactNode;
  /** Full-bleed media above the body, e.g. an <img>. */
  cover?: React.ReactNode;
  /** Footer action nodes, split into equal columns. */
  actions?: React.ReactNode[];
  /** Lift with shadow on hover. */
  hoverable?: boolean;
  /** "default" or "small" (tighter padding). */
  size?: "default" | "small";
  /** Draw the outer border. @default true */
  bordered?: boolean;
  bodyStyle?: React.CSSProperties;
  children?: React.ReactNode;
}

/**
 * Ant Design card — a bordered surface grouping related content, with optional
 * header, cover image and footer actions.
 */
export function Card(props: CardProps): JSX.Element;
