import React from "react";

const CSS = `
.ads-avatar { display: inline-flex; align-items: center; justify-content: center; overflow: hidden;
  color: #fff; background: var(--gray-6); font-family: var(--font-family); white-space: nowrap;
  vertical-align: middle; flex: none; }
.ads-avatar img { width: 100%; height: 100%; object-fit: cover; display: block; }
.ads-avatar-group { display: inline-flex; }
.ads-avatar-group .ads-avatar { border: 2px solid #fff; }
.ads-avatar-group .ads-avatar:not(:first-child) { margin-left: -8px; }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "avatar");
  el.textContent = CSS;
  document.head.appendChild(el);
}

const SIZES = { small: 24, default: 32, large: 40 };

export function Avatar({
  src,
  size = "default",
  shape = "circle",
  icon,
  children,
  style,
  className = "",
  ...rest
}) {
  inject();
  const px = typeof size === "number" ? size : SIZES[size] || 32;
  const css = {
    width: px,
    height: px,
    fontSize: Math.round(px / 2.2),
    borderRadius: shape === "square" ? "var(--radius)" : "50%",
    ...style,
  };
  return (
    <span className={"ads-avatar " + className} style={css} {...rest}>
      {src ? <img src={src} alt="" /> : children}
    </span>
  );
}

export function AvatarGroup({ children, className = "", ...rest }) {
  inject();
  return <span className={"ads-avatar-group " + className} {...rest}>{children}</span>;
}
