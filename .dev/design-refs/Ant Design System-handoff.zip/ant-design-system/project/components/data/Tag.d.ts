import * as React from "react";

export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Preset palette name (blue, green, red, gold, …) → soft tinted tag;
   *  any other CSS color → solid filled tag; omit for neutral. */
  color?: string;
  /** Show a close (×) affix. */
  closable?: boolean;
  onClose?: (e: React.MouseEvent) => void;
  /** Leading Ant icon name. */
  icon?: string;
  children?: React.ReactNode;
}

/**
 * Ant Design tag — compact label for categories, statuses or keywords.
 */
export function Tag(props: TagProps): JSX.Element;
