import * as React from "react";

export interface BadgeProps {
  /** Number shown in the count bubble. */
  count?: number;
  /** Render a small dot instead of a count. */
  dot?: boolean;
  /** Show the bubble even when count is 0. */
  showZero?: boolean;
  /** Cap displayed number, e.g. 99 → "99+". @default 99 */
  overflowCount?: number;
  /** Standalone status dot. */
  status?: "success" | "processing" | "default" | "error" | "warning";
  /** Label next to a status dot. */
  text?: React.ReactNode;
  /** Custom dot/bubble color (CSS color or token). */
  color?: string;
  /** Wrapped element the badge attaches to (e.g. an icon or avatar). */
  children?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Ant Design badge — count bubble or status dot, attached to a child or standalone.
 */
export function Badge(props: BadgeProps): JSX.Element;
