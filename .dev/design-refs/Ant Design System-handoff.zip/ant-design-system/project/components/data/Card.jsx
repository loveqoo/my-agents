import React from "react";

const CSS = `
.ads-card { background: var(--color-bg-container); border: 1px solid var(--color-border-secondary);
  border-radius: var(--radius-lg); font-family: var(--font-family); color: var(--color-text); overflow: hidden; }
.ads-card--hoverable { transition: box-shadow .2s, border-color .2s; cursor: pointer; }
.ads-card--hoverable:hover { box-shadow: var(--box-shadow); border-color: transparent; }
.ads-card-cover img { display: block; width: 100%; object-fit: cover; }
.ads-card-head { display: flex; align-items: center; justify-content: space-between; gap: 12px;
  min-height: 56px; padding: 0 24px; border-bottom: 1px solid var(--color-border-secondary); }
.ads-card--sm .ads-card-head { min-height: 38px; padding: 0 12px; }
.ads-card-title { font-size: 16px; font-weight: var(--font-weight-strong); color: var(--color-text-heading); }
.ads-card--sm .ads-card-title { font-size: 14px; }
.ads-card-extra { font-size: 14px; font-weight: 400; }
.ads-card-body { padding: 24px; }
.ads-card--sm .ads-card-body { padding: 12px; }
.ads-card-actions { display: flex; border-top: 1px solid var(--color-border-secondary); }
.ads-card-actions > * { flex: 1; display: flex; align-items: center; justify-content: center;
  padding: 12px 0; color: var(--color-text-tertiary); cursor: pointer; transition: color .2s; }
.ads-card-actions > *:hover { color: var(--color-primary); }
.ads-card-actions > *:not(:last-child) { border-right: 1px solid var(--color-border-secondary); }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "card");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Card({
  title,
  extra,
  cover,
  actions,
  hoverable = false,
  size = "default",
  bordered = true,
  children,
  className = "",
  style,
  bodyStyle,
  ...rest
}) {
  inject();
  const cls = [
    "ads-card",
    hoverable && "ads-card--hoverable",
    size === "small" && "ads-card--sm",
    className,
  ].filter(Boolean).join(" ");
  return (
    <div className={cls} style={{ border: bordered ? undefined : "none", ...style }} {...rest}>
      {cover ? <div className="ads-card-cover">{cover}</div> : null}
      {title || extra ? (
        <div className="ads-card-head">
          <span className="ads-card-title">{title}</span>
          {extra ? <span className="ads-card-extra">{extra}</span> : null}
        </div>
      ) : null}
      <div className="ads-card-body" style={bodyStyle}>{children}</div>
      {actions && actions.length ? (
        <div className="ads-card-actions">
          {actions.map((a, i) => <span key={i}>{a}</span>)}
        </div>
      ) : null}
    </div>
  );
}
