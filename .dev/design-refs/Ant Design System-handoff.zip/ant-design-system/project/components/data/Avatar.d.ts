import * as React from "react";

export interface AvatarProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Image URL. Falls back to children (initials) when absent. */
  src?: string;
  /** "small" 24 / "default" 32 / "large" 40, or a pixel number. */
  size?: "small" | "default" | "large" | number;
  /** "circle" (default) or "square". */
  shape?: "circle" | "square";
  /** Initials or a node shown when there's no image. */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

export interface AvatarGroupProps extends React.HTMLAttributes<HTMLSpanElement> {
  children?: React.ReactNode;
}

/** Ant Design avatar — user/entity image, initials or icon. */
export function Avatar(props: AvatarProps): JSX.Element;

/** Overlapping row of avatars. */
export function AvatarGroup(props: AvatarGroupProps): JSX.Element;
