import React from "react";

const CSS = `
.ads-badge { position: relative; display: inline-flex; line-height: 1; }
.ads-badge-count { position: absolute; top: 0; right: 0; transform: translate(50%, -50%);
  transform-origin: 100% 0%; min-width: 20px; height: 20px; padding: 0 6px; box-sizing: border-box;
  background: var(--color-error); color: #fff; font-family: var(--font-family); font-size: 12px;
  line-height: 20px; text-align: center; border-radius: 10px; box-shadow: 0 0 0 1px #fff;
  white-space: nowrap; z-index: 1; }
.ads-badge-dot { position: absolute; top: 0; right: 0; transform: translate(50%, -50%);
  width: 6px; height: 6px; background: var(--color-error); border-radius: 50%; box-shadow: 0 0 0 1px #fff; z-index: 1; }
.ads-badge-standalone { position: static; transform: none; }
.ads-badge-status { display: inline-flex; align-items: center; gap: 8px; font-family: var(--font-family); font-size: 14px; color: var(--color-text); }
.ads-badge-status-dot { width: 6px; height: 6px; border-radius: 50%; flex: none; }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "badge");
  el.textContent = CSS;
  document.head.appendChild(el);
}

const STATUS_COLORS = {
  success: "var(--color-success)",
  processing: "var(--color-primary)",
  default: "var(--gray-6)",
  error: "var(--color-error)",
  warning: "var(--color-warning)",
};

export function Badge({
  count,
  dot = false,
  showZero = false,
  overflowCount = 99,
  status,
  text,
  color,
  children,
  className = "",
  style,
  ...rest
}) {
  inject();

  // Status badge (standalone dot + text)
  if (status || (color && !children)) {
    const dotColor = status ? STATUS_COLORS[status] : color;
    return (
      <span className={"ads-badge-status " + className} style={style} {...rest}>
        <span className="ads-badge-status-dot" style={{ background: dotColor }} />
        {text != null ? <span>{text}</span> : null}
      </span>
    );
  }

  const display =
    typeof count === "number" && count > overflowCount ? `${overflowCount}+` : count;
  const hide = !dot && (count == null || (count === 0 && !showZero));

  const badgeEl = dot
    ? <span className={"ads-badge-dot" + (children ? "" : " ads-badge-standalone")} style={color ? { background: color } : undefined} />
    : !hide
      ? <span className={"ads-badge-count" + (children ? "" : " ads-badge-standalone")} style={color ? { background: color } : undefined}>{display}</span>
      : null;

  if (!children) return badgeEl || <span />;

  return (
    <span className={"ads-badge " + className} style={style} {...rest}>
      {children}
      {badgeEl}
    </span>
  );
}
