import React from "react";
import { Icon } from "../core/Icon.jsx";

const PRESETS = {
  blue: "geekblue", // alias handled below
};

const COLORS = ["blue","purple","cyan","green","magenta","red","orange","yellow","volcano","geekblue","gold","lime"];

const CSS = `
.ads-tag { display: inline-flex; align-items: center; gap: 4px; height: 22px; padding: 0 8px;
  font-family: var(--font-family); font-size: 12px; line-height: 20px; border-radius: var(--radius-sm);
  border: 1px solid transparent; white-space: nowrap; }
.ads-tag--default { background: var(--gray-2); border-color: var(--color-border); color: var(--color-text-secondary); }
.ads-tag-close { cursor: pointer; color: var(--color-text-tertiary); display: inline-flex; font-size: 10px; }
.ads-tag-close:hover { color: var(--color-text); }
.ads-tag--solid { color: #fff; border: none; }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "tag");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Tag({ color, children, closable = false, onClose, icon, className = "", style, ...rest }) {
  inject();
  let css = {};
  let cls = "ads-tag";
  if (!color) {
    cls += " ads-tag--default";
  } else if (COLORS.includes(color)) {
    css = {
      background: `var(--${color}-1)`,
      borderColor: `var(--${color}-3)`,
      color: `var(--${color}-7)`,
      border: "1px solid",
    };
  } else {
    // treat as a raw solid color (e.g. "#1677ff" or a token)
    cls += " ads-tag--solid";
    css = { background: color };
  }
  return (
    <span className={cls + " " + className} style={{ ...css, ...style }} {...rest}>
      {icon ? <Icon name={icon} /> : null}
      {children}
      {closable ? <span className="ads-tag-close" onClick={onClose}><Icon name="close" /></span> : null}
    </span>
  );
}
