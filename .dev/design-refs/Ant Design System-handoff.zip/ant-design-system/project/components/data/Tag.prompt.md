**Tag** — compact label for categories, keywords or inline statuses. A preset palette name gives a soft tinted tag; any raw CSS color gives a solid fill.

```jsx
<Tag>default</Tag>
<Tag color="green">success</Tag>
<Tag color="gold" icon="clock-circle">pending</Tag>
<Tag color="#1677ff">solid</Tag>
<Tag closable onClose={fn}>removable</Tag>
```

Presets: blue, purple, cyan, green, magenta, red, orange, yellow, volcano, geekblue, gold, lime.
