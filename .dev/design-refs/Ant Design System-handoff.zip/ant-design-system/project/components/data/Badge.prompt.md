**Badge** — small count bubble or status dot for notifications and states.

```jsx
<Badge count={5}><Icon name="bell" size={20} /></Badge>
<Badge dot><Icon name="mail" size={20} /></Badge>
<Badge count={120} overflowCount={99} />
<Badge status="success" text="Running" />
<Badge status="error" text="Failed" />
```

Wrap an element to anchor the bubble to its corner, or render standalone (status dot + text).
