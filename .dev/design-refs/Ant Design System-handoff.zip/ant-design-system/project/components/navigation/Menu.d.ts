import * as React from "react";

export interface MenuItem {
  key: string;
  label: React.ReactNode;
  /** Leading Ant icon name. */
  icon?: string;
  disabled?: boolean;
  /** "group" renders a non-clickable section heading with `children`. */
  type?: "item" | "group";
  children?: MenuItem[];
}

export interface MenuProps {
  items: MenuItem[];
  selectedKey?: string;
  defaultSelectedKey?: string;
  onSelect?: (key: string) => void;
  /** "inline" vertical or "horizontal". @default "inline" */
  mode?: "inline" | "horizontal";
  /** "light" or "dark" (navy sider). @default "light" */
  theme?: "light" | "dark";
  /** Collapse to icon-only: hides labels and group titles, centers icons. @default false */
  collapsed?: boolean;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Ant Design menu — primary navigation list for siders and headers.
 */
export function Menu(props: MenuProps): JSX.Element;
