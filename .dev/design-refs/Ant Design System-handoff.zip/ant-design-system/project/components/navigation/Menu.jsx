import React from "react";
import { Icon } from "../core/Icon.jsx";

const CSS = `
.ads-menu { font-family: var(--font-family); font-size: 14px; list-style: none; margin: 0; padding: 0; }
.ads-menu--inline { border-right: 1px solid var(--color-border-secondary); }
.ads-menu-item { display: flex; align-items: center; gap: 10px; height: 40px; padding: 0 16px;
  color: var(--color-text); cursor: pointer; position: relative; border-radius: var(--radius);
  margin: 4px 8px; transition: background .2s, color .2s; }
.ads-menu--inline .ads-menu-item { margin: 4px; }
.ads-menu-item:hover { background: var(--color-fill-tertiary); }
.ads-menu-item--selected { background: var(--color-primary-bg); color: var(--color-primary); font-weight: var(--font-weight-medium); }
.ads-menu-item--selected:hover { background: var(--color-primary-bg); }
.ads-menu-item--disabled { color: var(--color-text-disabled); cursor: not-allowed; }
.ads-menu-item--disabled:hover { background: transparent; }
.ads-menu-icon { font-size: 16px; flex: none; }
.ads-menu-label { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ads-menu-group-title { padding: 8px 16px 4px; color: var(--color-text-tertiary); font-size: 12px; }

/* collapsed (icon-only) */
.ads-menu--collapsed .ads-menu-item { justify-content: center; padding: 0; gap: 0; }
.ads-menu--collapsed .ads-menu-label { display: none; }
.ads-menu--collapsed .ads-menu-group-title { display: none; }

/* dark theme (sider) */
.ads-menu--dark { background: #001529; color: rgba(255,255,255,.65); }
.ads-menu--dark.ads-menu--inline { border-right: none; }
.ads-menu--dark .ads-menu-item { color: rgba(255,255,255,.65); }
.ads-menu--dark .ads-menu-item:hover { background: rgba(255,255,255,.08); color: #fff; }
.ads-menu--dark .ads-menu-item--selected { background: var(--color-primary); color: #fff; }
.ads-menu--dark .ads-menu-item--selected:hover { background: var(--color-primary); }
.ads-menu--dark .ads-menu-group-title { color: rgba(255,255,255,.45); }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "menu");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Menu({
  items = [],
  selectedKey,
  defaultSelectedKey,
  onSelect,
  mode = "inline",
  theme = "light",
  collapsed = false,
  className = "",
  style,
  ...rest
}) {
  inject();
  const isControlled = selectedKey !== undefined;
  const [internal, setInternal] = React.useState(defaultSelectedKey);
  const sel = isControlled ? selectedKey : internal;

  const pick = (k, disabled) => {
    if (disabled) return;
    if (!isControlled) setInternal(k);
    onSelect && onSelect(k);
  };

  const cls = ["ads-menu", `ads-menu--${mode}`, `ads-menu--${theme}`, collapsed && "ads-menu--collapsed", className].filter(Boolean).join(" ");

  const renderItem = (it) => {
    if (it.type === "group") {
      return (
        <li key={it.key || it.label} role="presentation" className="ads-menu-group">
          {it.label ? <div className="ads-menu-group-title">{it.label}</div> : null}
          <ul className="ads-menu-group-list" style={{ listStyle: "none", margin: 0, padding: 0 }}>
            {(it.children || []).map(renderItem)}
          </ul>
        </li>
      );
    }
    const icls = ["ads-menu-item", it.key === sel && "ads-menu-item--selected", it.disabled && "ads-menu-item--disabled"].filter(Boolean).join(" ");
    return (
      <li key={it.key} className={icls} onClick={() => pick(it.key, it.disabled)}>
        {it.icon ? <span className="ads-menu-icon"><Icon name={it.icon} /></span> : null}
        <span className="ads-menu-label">{it.label}</span>
      </li>
    );
  };

  return <ul className={cls} style={style} {...rest}>{items.map(renderItem)}</ul>;
}
