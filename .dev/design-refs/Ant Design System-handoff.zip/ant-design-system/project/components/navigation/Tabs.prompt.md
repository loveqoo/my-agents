**Tabs** — switch between sibling views within the same context. Underline (`line`) or `card` style.

```jsx
<Tabs defaultActiveKey="1" items={[
  { key: "1", label: "Overview", children: <Overview/> },
  { key: "2", label: "Activity", children: <Activity/> },
  { key: "3", label: "Settings", disabled: true },
]} />
```

Provide `items` with `key`/`label`/`children`. Controlled via `activeKey`+`onChange`.
