**Breadcrumb** — page hierarchy trail. Last item is the current page (non-link).

```jsx
<Breadcrumb items={[
  { title: "Home", icon: "home", onClick: goHome },
  { title: "Projects" },
  { title: "Ant Design" },
]} />
```
Default separator is a chevron; override with `separator`.
