import React from "react";
import { Icon } from "../core/Icon.jsx";

const CSS = `
.ads-breadcrumb { font-family: var(--font-family); font-size: 14px; display: flex; align-items: center; flex-wrap: wrap; }
.ads-breadcrumb-item { display: inline-flex; align-items: center; gap: 4px; color: var(--color-text-secondary); }
.ads-breadcrumb-link { color: var(--color-text-secondary); cursor: pointer; transition: color .2s; padding: 0 4px; border-radius: var(--radius-sm); }
.ads-breadcrumb-link:hover { color: var(--color-text); background: var(--color-fill-tertiary); }
.ads-breadcrumb-item.is-last { color: var(--color-text); }
.ads-breadcrumb-sep { margin: 0 8px; color: var(--color-text-quaternary); display: inline-flex; }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "breadcrumb");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Breadcrumb({ items = [], separator = "/", className = "", style }) {
  inject();
  return (
    <nav className={"ads-breadcrumb " + className} style={style}>
      {items.map((it, i) => {
        const last = i === items.length - 1;
        return (
          <React.Fragment key={i}>
            <span className={"ads-breadcrumb-item" + (last ? " is-last" : "")}>
              {it.icon ? <Icon name={it.icon} size="14px" /> : null}
              {last ? (it.title ?? it.label) : (
                <span className="ads-breadcrumb-link" onClick={it.onClick}>{it.title ?? it.label}</span>
              )}
            </span>
            {!last ? <span className="ads-breadcrumb-sep">{separator === "/" ? <Icon name="right" size="11px" /> : separator}</span> : null}
          </React.Fragment>
        );
      })}
    </nav>
  );
}
