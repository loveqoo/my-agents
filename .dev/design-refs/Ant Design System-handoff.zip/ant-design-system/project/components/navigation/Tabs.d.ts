import * as React from "react";

export interface TabItem {
  key: string;
  label: React.ReactNode;
  children?: React.ReactNode;
  disabled?: boolean;
}

export interface TabsProps {
  items: TabItem[];
  activeKey?: string;
  defaultActiveKey?: string;
  onChange?: (key: string) => void;
  /** "line" (underline) or "card". @default "line" */
  type?: "line" | "card";
  className?: string;
}

/**
 * Ant Design tabs — switch between sibling views in the same context.
 */
export function Tabs(props: TabsProps): JSX.Element;
