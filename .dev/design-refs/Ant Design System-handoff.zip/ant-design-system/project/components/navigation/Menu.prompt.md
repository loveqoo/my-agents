**Menu** — primary navigation list. Use `theme="dark"` for the classic navy AntD sider; `mode="inline"` for vertical, `mode="horizontal"` for a top bar.

```jsx
<Menu mode="inline" theme="dark" defaultSelectedKey="dash" items={[
  { key: "dash", label: "Dashboard", icon: "dashboard" },
  { key: "users", label: "Users", icon: "team" },
  { type: "group", label: "Settings", children: [
    { key: "profile", label: "Profile", icon: "user" },
  ]},
]} />
```

Items take `key`/`label`/`icon`/`disabled`. `onSelect(key)` fires on click.
