import * as React from "react";

export interface BreadcrumbItem {
  title?: React.ReactNode;
  label?: React.ReactNode;
  /** Leading Icon name. */
  icon?: string;
  onClick?: () => void;
}

export interface BreadcrumbProps {
  items: BreadcrumbItem[];
  separator?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

/** Ant Design breadcrumb trail. */
export function Breadcrumb(props: BreadcrumbProps): JSX.Element;
