import React from "react";

const CSS = `
.ads-tabs { font-family: var(--font-family); }
.ads-tabs-nav { display: flex; gap: 32px; border-bottom: 1px solid var(--color-border-secondary); position: relative; }
.ads-tabs-tab { position: relative; padding: 12px 0; font-size: 14px; color: var(--color-text);
  cursor: pointer; transition: color .2s; }
.ads-tabs-tab:hover { color: var(--color-primary-hover); }
.ads-tabs-tab--active { color: var(--color-primary); font-weight: var(--font-weight-medium); }
.ads-tabs-tab--disabled { color: var(--color-text-disabled); cursor: not-allowed; }
.ads-tabs-tab--active::after { content: ""; position: absolute; left: 0; right: 0; bottom: -1px;
  height: 2px; background: var(--color-primary); }
.ads-tabs-tab span { display: inline-flex; align-items: center; gap: 8px; }
.ads-tabs-content { padding-top: 16px; }

/* card type */
.ads-tabs--card .ads-tabs-nav { gap: 2px; border-bottom: 1px solid var(--color-border-secondary); }
.ads-tabs--card .ads-tabs-tab { padding: 8px 16px; background: var(--gray-2);
  border: 1px solid var(--color-border-secondary); border-radius: var(--radius) var(--radius) 0 0; margin-bottom: -1px; }
.ads-tabs--card .ads-tabs-tab--active { background: var(--color-bg-container); border-bottom-color: var(--color-bg-container); }
.ads-tabs--card .ads-tabs-tab--active::after { display: none; }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "tabs");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Tabs({
  items = [],
  activeKey,
  defaultActiveKey,
  onChange,
  type = "line",
  className = "",
  ...rest
}) {
  inject();
  const isControlled = activeKey !== undefined;
  const [internal, setInternal] = React.useState(defaultActiveKey ?? (items[0] && items[0].key));
  const active = isControlled ? activeKey : internal;

  const pick = (k, disabled) => {
    if (disabled) return;
    if (!isControlled) setInternal(k);
    onChange && onChange(k);
  };

  const current = items.find((i) => i.key === active);
  const cls = ["ads-tabs", type === "card" && "ads-tabs--card", className].filter(Boolean).join(" ");

  return (
    <div className={cls} {...rest}>
      <div className="ads-tabs-nav">
        {items.map((it) => {
          const tcls = ["ads-tabs-tab", it.key === active && "ads-tabs-tab--active", it.disabled && "ads-tabs-tab--disabled"].filter(Boolean).join(" ");
          return <div key={it.key} className={tcls} onClick={() => pick(it.key, it.disabled)}><span>{it.label}</span></div>;
        })}
      </div>
      {current && current.children != null ? <div className="ads-tabs-content">{current.children}</div> : null}
    </div>
  );
}
