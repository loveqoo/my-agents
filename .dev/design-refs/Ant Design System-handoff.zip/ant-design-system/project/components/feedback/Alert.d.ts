import * as React from "react";

export interface AlertProps {
  /** Severity → color + icon. @default "info" */
  type?: "success" | "info" | "warning" | "error";
  /** Primary message line. */
  message: React.ReactNode;
  /** Optional longer description (switches to the taller layout). */
  description?: React.ReactNode;
  /** Show the leading status icon. */
  showIcon?: boolean;
  /** Show a close (×) affix. */
  closable?: boolean;
  onClose?: () => void;
  /** Trailing action node (e.g. a Button). */
  action?: React.ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Ant Design alert — inline contextual feedback banner.
 */
export function Alert(props: AlertProps): JSX.Element;
