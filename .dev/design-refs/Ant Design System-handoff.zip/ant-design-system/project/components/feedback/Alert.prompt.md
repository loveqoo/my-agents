**Alert** — inline banner giving contextual feedback about an action or state. Four severities; add `description` for a two-line layout.

```jsx
<Alert type="success" message="Saved successfully" showIcon />
<Alert type="warning" message="Your trial ends soon" showIcon closable />
<Alert type="error" message="Upload failed"
  description="The file exceeds the 10 MB limit." showIcon />
```

Use for persistent page-level messages; use a Toast/message for transient ones.
