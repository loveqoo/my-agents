import * as React from "react";

export interface ModalProps {
  open?: boolean;
  title?: React.ReactNode;
  children?: React.ReactNode;
  okText?: React.ReactNode;
  cancelText?: React.ReactNode;
  okType?: "primary" | "default";
  okDanger?: boolean;
  /** Replace the footer; pass null to hide it. */
  footer?: React.ReactNode | null;
  width?: number;
  onOk?: () => void;
  onCancel?: () => void;
}

/** Ant Design modal dialog with mask + default OK/Cancel footer. */
export function Modal(props: ModalProps): JSX.Element | null;
