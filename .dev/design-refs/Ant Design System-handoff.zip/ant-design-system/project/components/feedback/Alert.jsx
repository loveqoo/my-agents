import React from "react";
import { Icon } from "../core/Icon.jsx";

const CSS = `
.ads-alert { display: flex; align-items: flex-start; gap: 8px; padding: 8px 12px; border-radius: var(--radius-lg);
  border: 1px solid transparent; font-family: var(--font-family); font-size: 14px; line-height: 1.5714; color: var(--color-text); }
.ads-alert--with-desc { padding: 16px; align-items: flex-start; }
.ads-alert-icon { font-size: 16px; flex: none; margin-top: 1px; }
.ads-alert--with-desc .ads-alert-icon { font-size: 22px; margin-top: 0; }
.ads-alert-content { flex: 1; min-width: 0; }
.ads-alert-message { color: var(--color-text); }
.ads-alert--with-desc .ads-alert-message { font-size: 16px; font-weight: var(--font-weight-medium); margin-bottom: 4px; color: var(--color-text-heading); }
.ads-alert-desc { color: var(--color-text-secondary); font-size: 14px; }
.ads-alert-close { flex: none; cursor: pointer; color: var(--color-text-tertiary); font-size: 12px; display: inline-flex; }
.ads-alert-close:hover { color: var(--color-text); }

.ads-alert--success { background: var(--color-success-bg); border-color: var(--color-success-border); }
.ads-alert--success .ads-alert-icon { color: var(--color-success); }
.ads-alert--info { background: var(--color-primary-bg); border-color: var(--color-primary-border); }
.ads-alert--info .ads-alert-icon { color: var(--color-primary); }
.ads-alert--warning { background: var(--color-warning-bg); border-color: var(--color-warning-border); }
.ads-alert--warning .ads-alert-icon { color: var(--color-warning); }
.ads-alert--error { background: var(--color-error-bg); border-color: var(--color-error-border); }
.ads-alert--error .ads-alert-icon { color: var(--color-error); }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "alert");
  el.textContent = CSS;
  document.head.appendChild(el);
}

const ICONS = {
  success: "check-circle",
  info: "info-circle",
  warning: "exclamation-circle",
  error: "close-circle",
};

export function Alert({
  type = "info",
  message,
  description,
  showIcon = false,
  closable = false,
  onClose,
  action,
  className = "",
  style,
  ...rest
}) {
  inject();
  const [closed, setClosed] = React.useState(false);
  if (closed) return null;
  const withDesc = !!description;
  const cls = ["ads-alert", `ads-alert--${type}`, withDesc && "ads-alert--with-desc", className].filter(Boolean).join(" ");
  return (
    <div className={cls} style={style} role="alert" {...rest}>
      {showIcon ? <span className="ads-alert-icon"><Icon name={ICONS[type]} /></span> : null}
      <div className="ads-alert-content">
        <div className="ads-alert-message">{message}</div>
        {description ? <div className="ads-alert-desc">{description}</div> : null}
      </div>
      {action ? <span style={{ flex: "none" }}>{action}</span> : null}
      {closable ? (
        <span className="ads-alert-close" onClick={() => { setClosed(true); onClose && onClose(); }}>
          <Icon name="close" />
        </span>
      ) : null}
    </div>
  );
}
