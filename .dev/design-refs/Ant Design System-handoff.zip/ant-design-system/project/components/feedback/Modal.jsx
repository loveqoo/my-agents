import React from "react";
import { Icon } from "../core/Icon.jsx";
import { Button } from "../forms/Button.jsx";

const CSS = `
.ads-modal-mask { position: fixed; inset: 0; background: var(--color-bg-mask); z-index: 1000; animation: adsFade .2s; }
.ads-modal-wrap { position: fixed; inset: 0; z-index: 1000; display: flex; align-items: flex-start; justify-content: center; overflow: auto; padding: 100px 16px 16px; }
.ads-modal {
  position: relative; width: 520px; max-width: 100%; background: var(--color-bg-elevated);
  border-radius: var(--radius-lg); box-shadow: var(--box-shadow); font-family: var(--font-family);
  animation: adsZoom .2s cubic-bezier(.08,.82,.17,1);
}
.ads-modal-close { position: absolute; top: 16px; right: 16px; cursor: pointer; color: var(--color-text-tertiary); width: 22px; height: 22px; display: inline-flex; align-items: center; justify-content: center; border-radius: var(--radius-sm); transition: all .2s; }
.ads-modal-close:hover { color: var(--color-text); background: var(--color-fill-tertiary); }
.ads-modal-header { padding: 16px 24px 0; }
.ads-modal-title { font-size: 16px; font-weight: var(--font-weight-strong); color: var(--color-text-heading); }
.ads-modal-body { padding: 12px 24px 24px; font-size: 14px; color: var(--color-text); line-height: 1.5714; }
.ads-modal-footer { display: flex; justify-content: flex-end; gap: 8px; padding: 0 24px 20px; }
@keyframes adsFade { from { opacity: 0 } to { opacity: 1 } }
@keyframes adsZoom { from { transform: scale(.92); opacity: 0 } to { transform: scale(1); opacity: 1 } }
`;

let injected = false;
function inject() {
  if (injected || typeof document === "undefined") return;
  injected = true;
  const el = document.createElement("style");
  el.setAttribute("data-ads", "modal");
  el.textContent = CSS;
  document.head.appendChild(el);
}

export function Modal({
  open = false,
  title,
  children,
  okText = "OK",
  cancelText = "Cancel",
  okType = "primary",
  okDanger = false,
  footer,
  width = 520,
  onOk,
  onCancel,
}) {
  inject();
  if (!open) return null;
  return (
    <div>
      <div className="ads-modal-mask" onClick={onCancel} />
      <div className="ads-modal-wrap" onClick={(e) => { if (e.target === e.currentTarget) onCancel && onCancel(); }}>
        <div className="ads-modal" style={{ width }}>
          <span className="ads-modal-close" onClick={onCancel}><Icon name="close" size="16px" /></span>
          {title ? <div className="ads-modal-header"><span className="ads-modal-title">{title}</span></div> : null}
          <div className="ads-modal-body">{children}</div>
          {footer !== null ? (
            <div className="ads-modal-footer">
              {footer || (
                <>
                  <Button onClick={onCancel}>{cancelText}</Button>
                  <Button type={okType} danger={okDanger} onClick={onOk}>{okText}</Button>
                </>
              )}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
