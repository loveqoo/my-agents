**Modal** — centered dialog over a mask. Controlled by `open`; renders nothing when closed.

```jsx
<Modal open={open} title="Confirm" onOk={save} onCancel={() => setOpen(false)}>
  Are you sure?
</Modal>
<Modal open={open} title="Delete" okText="Delete" okDanger onCancel={close}>…</Modal>
```
Default footer is Cancel + OK. Pass `footer={null}` to hide, or a node to replace.
