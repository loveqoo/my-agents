/* my-agents debug console — app shell. Wires agent selection, conversation state,
   fake LangGraph runs with captured traces, and the turn → Inspector link. */

function AgentDebugApp() {
  const agents = window.AGENTS;
  const [activeId, setActiveId] = React.useState("research");
  const [convos, setConvos] = React.useState(window.AGENT_SEED);
  const [streaming, setStreaming] = React.useState(false);
  const [showPrompt, setShowPrompt] = React.useState(false);
  const [selectedTurn, setSelectedTurn] = React.useState(null);
  const [inspectorOpen, setInspectorOpen] = React.useState(false);
  const timer = React.useRef(null);

  const agent = agents.find((a) => a.id === activeId);
  const messages = convos[activeId] || [];

  // default-select the latest assistant turn with a trace
  React.useEffect(() => {
    const idx = [...messages].map((m, i) => ({ m, i })).reverse().find((x) => x.m.role === "ai" && x.m.trace);
    setSelectedTurn(idx ? idx.i : null);
    // eslint-disable-next-line
  }, [activeId]);

  const stop = () => { if (timer.current) { clearInterval(timer.current); timer.current = null; } setStreaming(false); };

  const streamReply = (id, full, trace) => {
    setStreaming(true);
    setConvos((c) => ({ ...c, [id]: [...(c[id] || []), { role: "ai", text: "" }] }));
    let i = 0; const step = Math.max(2, Math.round(full.length / 80));
    timer.current = setInterval(() => {
      i += step;
      const slice = full.slice(0, i);
      setConvos((c) => {
        const arr = (c[id] || []).slice();
        arr[arr.length - 1] = { role: "ai", text: slice };
        return { ...c, [id]: arr };
      });
      if (i >= full.length) {
        clearInterval(timer.current); timer.current = null; setStreaming(false);
        setConvos((c) => {
          const arr = (c[id] || []).slice();
          arr[arr.length - 1] = { role: "ai", text: full, trace };
          setSelectedTurn(arr.length - 1);
          return { ...c, [id]: arr };
        });
      }
    }, 38);
  };

  // User submitted an A2UI surface — the action + data model flow back to the agent.
  const onA2UIAction = (msgIndex, action, data) => {
    if (streaming) return;
    const id = activeId;
    setConvos((c) => {
      const arr = (c[id] || []).slice();
      if (arr[msgIndex] && arr[msgIndex].role === "a2ui") arr[msgIndex] = { ...arr[msgIndex], state: "submitted", submitted: data };
      return { ...c, [id]: arr };
    });
    const f = (data && data.form) || {};
    const base = window.runAgent(agent, "confirm " + (action && action.name));
    base.text = "\uc644\ub8cc \u2014 \"" + (f.title || "\ud68c\uc758") + "\" \uc77c\uc815\uc744 " + (f.date || "") + " " + (f.time || "") + "\uc5d0 " + (f.attendees || "\ud300") + "\uacfc(\uc640) \uc7a1\uc558\uc2b5\ub2c8\ub2e4" + (f.remind ? ", \ud558\ub8e8 \uc804 \ubaa8\ub450\uc5d0\uac8c \ub9ac\ub9c8\uc778\ub354\ub3c4 \ubcf4\ub0bc\uac8c\uc694" : "") + ". A2UI \uc561\uc158 " + (action && action.name) + "\uc774(\uac00) \ud3fc \ub370\uc774\ud130 \ubaa8\ub378\uacfc \ud568\uaed8 \uc800\uc5d0\uac8c \ud68c\uc2e0\ub418\uc5c8\uc2b5\ub2c8\ub2e4.";
    setTimeout(() => streamReply(id, base.text, base.trace), 260);
  };

  const send = (text) => {
    if (streaming) return;
    const id = activeId;
    setConvos((c) => ({ ...c, [id]: [...(c[id] || []), { role: "me", text }] }));
    const plan = window.planAgent(agent, text);
    if (plan.type === "a2ui") {
      // Agent replies with generative UI (A2UI) instead of text.
      setTimeout(() => {
        setConvos((c) => ({ ...c, [id]: [...(c[id] || []), {
          role: "a2ui", id: "srf-" + Date.now(), surface: plan.surface, state: "open",
        }] }));
      }, 260);
      return;
    }
    if (plan.type === "interrupt") {
      // Run hit interrupt() — pause at a checkpoint and surface an approval request.
      setTimeout(() => {
        setConvos((c) => ({ ...c, [id]: [...(c[id] || []), {
          role: "approval", id: "apr-" + Date.now(),
          approver: plan.approver, permission: plan.permission, tool: plan.tool,
          args: plan.args, summary: plan.summary, checkpoint: plan.checkpoint,
          state: plan.approver === "admin" ? "routed" : "pending",
        }] }));
      }, 260);
      return;
    }
    setTimeout(() => streamReply(id, plan.text, plan.trace), 260);
  };

  // Resolve an inline (user) approval, then resume the run from its checkpoint.
  const resolveApproval = (msgIndex, decision) => {
    if (streaming) return;
    const id = activeId;
    const info = (convos[id] || [])[msgIndex];
    if (!info || info.role !== "approval") return;
    setConvos((c) => {
      const arr = (c[id] || []).slice();
      arr[msgIndex] = { ...info, state: decision === "approve" ? "approved" : "rejected" };
      return { ...c, [id]: arr };
    });
    const resumed = window.resumeAgent(agent, info, decision);
    setTimeout(() => streamReply(id, resumed.text, resumed.trace), 260);
  };

  const switchAgent = (id) => { stop(); setActiveId(id); setShowPrompt(false); };

  // Clicking a turn's "인스펙터" chip opens the panel on that turn.
  const openInspector = (i) => { setSelectedTurn(i); setInspectorOpen(true); };

  const selectedMsg = selectedTurn != null ? messages[selectedTurn] : null;

  return (
    <div style={{ height: "100%", display: "flex", background: "var(--color-bg-container)" }}>
      <window.DebugChat
        agent={agent}
        agents={agents}
        onSwitchAgent={switchAgent}
        messages={messages}
        streaming={streaming}
        selectedTurn={inspectorOpen ? selectedTurn : null}
        onSelectTurn={openInspector}
        onSend={send}
        onResolveApproval={resolveApproval}
        onA2UIAction={onA2UIAction}
        onStop={stop}
        showPrompt={showPrompt}
        onTogglePrompt={() => setShowPrompt((s) => !s)}
        inspectorOpen={inspectorOpen}
        onToggleInspector={() => setInspectorOpen((o) => !o)}
      />
      {inspectorOpen ? (
        <window.Inspector agent={agent} turn={selectedMsg} turnIndex={selectedTurn || 0} onClose={() => setInspectorOpen(false)} />
      ) : null}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<AgentDebugApp />);
