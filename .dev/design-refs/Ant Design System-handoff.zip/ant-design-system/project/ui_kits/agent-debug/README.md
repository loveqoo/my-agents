# Agent Debug Console — `my-agents`

An interactive debugging UI for **my-agents**, a personal service for managing
LangChain / LangGraph agents (compose an agent from persona + memory policy +
permissions + MCP servers, then chat with it). This screen is the **debug view**:
pick a built agent, run a conversation, and inspect exactly what happened on every
turn. Built from this design system's antd + Ant Design X primitives.

## Run
Open [`index.html`](index.html).

## Layout (3 panes)
1. **Left — Agent selector.** Each agent shows status dot, model, persona and its
   MCP servers. Selecting an agent loads its conversation and config.
2. **Center — Debug chat.** Header surfaces the agent's model/persona, exposure
   badges (**A2A** / **MCP server**), and a **System prompt** toggle that reveals
   the resolved prompt plus memory-policy / permission / MCP tags. Messages use
   Ant Design X `Bubble`s with **fake streaming**; each assistant turn carries an
   **Inspect** chip (memory count · MCP count · latency) — click it to drive the
   inspector.
3. **Right — Turn inspector.** For the selected turn: latency + token metrics, the
   **system prompt** used, **retrieved memories** (type + relevance bar), **MCP
   tool calls** (server.tool, args, result, duration, ok/error), and the
   **LangGraph execution path** (`__start__ → retrieve_memory → tools →
   call_model → __end__` with per-node timing).

## Flow (all fake / local)
- Type a message (or click a debug prompt) → the agent "runs", streams a reply,
  and a trace is captured and auto-selected in the inspector.
- Click any earlier assistant turn's **Inspect** chip to review its trace.
- Switch agents in the left rail to debug a different one.

## Human-in-the-loop (HIL)
When a prompt would trigger a permission whose **approver** isn't `auto`, the run
hits `interrupt()`, pauses at a **checkpoint**, and surfaces an approval request:
- **`user` approver** (e.g. Personal Secretary · `mail.send`) → an **inline
  approval card** with Approve / Reject. Approving **resumes from the checkpoint**
  and streams the result; the inspector's LangGraph path then shows
  `resume → checkpoint_load → tools → call_model`.
- **`admin` approver** (e.g. Code Reviewer · `repo.merge`, Ops Copilot ·
  `k8s.write`) → the card shows it's **routed to the admin console's approvals
  queue**; the session waits there. Resolve it in `ui_kits/admin/` → Approvals.

Try the **"Trigger HIL approval"** starter prompt on each agent to see both paths.

## Generative UI (A2UI)
Send **"Schedule a meeting with the team"** (or click the **Generative UI (A2UI)**
starter) and the agent replies with an **`A2UISurface`** instead of text — an
interactive form (title, date, time, attendees, reminder) rendered from a streamed
A2UI command set into native DS components, bound to a live data model. Filling it
in and pressing **Confirm** dispatches the action + data model back to the agent,
which then streams a confirmation. This is the same generative-UI mechanism antd-x
ships as `@ant-design/x-card`.

## Files
- `index.html` — shell + loader (also a Starting Point).
- `agentData.js` — agents (persona/memory/permissions/MCP/system prompt), seed
  turns with traces, and `runAgent()` which fabricates a trace from the config.
- `AgentList.jsx` — left agent selector.
- `DebugChat.jsx` — center chat + system-prompt panel + trace chips.
- `Inspector.jsx` — right per-turn prompt / memory / MCP / graph panel.
- `App.jsx` — shell: agent + conversation state, fake streaming, turn selection.

## Components exercised
`Bubble`/`BubbleList`, `Sender`, `Welcome`, `Prompts` (Ant Design X) + `Tag`,
`Avatar`, `Button`, `Icon` (antd). The inspector sections are bespoke debug UI
built on the same tokens.

Swap `runAgent()` for a real LangGraph stream (and feed real prompt/memory/MCP
trace data into the inspector) to make this a live debugger.
