/* my-agents debug console — right rail: per-turn Inspector.
   Shows the resolved system prompt, retrieved memories, MCP tool calls and the
   LangGraph execution path for the currently-selected assistant turn. */
const NS_IN = window.AntDesignSystem_b19dda;
const { Tag: IN_Tag, Icon: IN_Icon, Button: IN_Button } = NS_IN;

function Section({ icon, iconColor, title, count, children, defaultOpen = true }) {
  const [open, setOpen] = React.useState(defaultOpen);
  return (
    <div style={{ borderBottom: "1px solid var(--color-border-secondary)" }}>
      <button onClick={() => setOpen((o) => !o)} style={{
        width: "100%", display: "flex", alignItems: "center", gap: 8, padding: "12px 16px",
        background: "transparent", border: "none", cursor: "pointer", font: "inherit",
      }}>
        <span style={{ color: iconColor, display: "inline-flex" }}><IN_Icon name={icon} size={15} /></span>
        <span style={{ fontSize: 13, fontWeight: 600, color: "var(--color-text-heading)", flex: 1, textAlign: "left" }}>{title}</span>
        {count != null ? <IN_Tag>{count}</IN_Tag> : null}
        <span style={{ color: "var(--color-text-tertiary)", transform: open ? "rotate(90deg)" : "none", transition: "transform .2s", display: "inline-flex" }}>
          <IN_Icon name="right" size={11} />
        </span>
      </button>
      {open ? <div style={{ padding: "0 16px 16px" }}>{children}</div> : null}
    </div>
  );
}

const codeBox = {
  fontFamily: "var(--font-family-code)", fontSize: 12, lineHeight: 1.6, color: "var(--color-text)",
  background: "var(--gray-2)", border: "1px solid var(--color-border-secondary)", borderRadius: 6,
  padding: "10px 12px", whiteSpace: "pre-wrap", wordBreak: "break-word", margin: 0, overflow: "auto",
};

function MemoryRow({ m }) {
  const pct = Math.round(m.score * 100);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6, padding: "10px 0", borderTop: "1px solid var(--color-border-secondary)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <IN_Tag color={m.type === "semantic" ? "geekblue" : "purple"}>{m.type}</IN_Tag>
        <div style={{ flex: 1 }} />
        <span style={{ fontSize: 11, color: "var(--color-text-tertiary)", fontFamily: "var(--font-family-code)" }}>{pct}%</span>
      </div>
      <div style={{ fontSize: 13, color: "var(--color-text)", lineHeight: 1.5 }}>{m.text}</div>
      <div style={{ height: 4, background: "var(--color-fill-secondary)", borderRadius: 100, overflow: "hidden" }}>
        <div style={{ width: pct + "%", height: "100%", background: "var(--geekblue-5)", borderRadius: 100 }} />
      </div>
    </div>
  );
}

function McpCall({ c }) {
  return (
    <div style={{ border: "1px solid var(--color-border-secondary)", borderRadius: 8, padding: 12, marginTop: 10 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <IN_Icon name={c.status === "ok" ? "check-circle" : "close-circle"} size={14}
          style={{ color: c.status === "ok" ? "var(--color-success)" : "var(--color-error)" }} />
        <span style={{ fontSize: 13, fontFamily: "var(--font-family-code)", color: "var(--color-text-heading)" }}>
          <span style={{ color: "var(--cyan-7)" }}>{c.server}</span>.{c.tool}
        </span>
        <div style={{ flex: 1 }} />
        <span style={{ fontSize: 11, color: "var(--color-text-tertiary)", fontFamily: "var(--font-family-code)" }}>{c.ms} ms</span>
      </div>
      <div style={{ fontSize: 11, color: "var(--color-text-tertiary)", marginBottom: 3 }}>args</div>
      <pre style={{ ...codeBox, marginBottom: 8 }}>{JSON.stringify(c.args)}</pre>
      <div style={{ fontSize: 11, color: "var(--color-text-tertiary)", marginBottom: 3 }}>result</div>
      <div style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>{c.result}</div>
    </div>
  );
}

function GraphPath({ graph }) {
  const special = { interrupt: "var(--gold-6)", checkpoint_load: "var(--purple-6)", checkpoint_save: "var(--purple-6)", resume: "var(--purple-6)" };
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
      {graph.map((n, i) => {
        const term = n.node.startsWith("__");
        const sp = special[n.node];
        const dot = sp || (term ? "var(--gray-6)" : "var(--color-primary)");
        return (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flex: "none" }}>
              <span style={{ width: 9, height: 9, borderRadius: "50%", flex: "none", background: dot }} />
              {i < graph.length - 1 ? <span style={{ width: 2, height: 22, background: "var(--color-border)" }} /> : null}
            </div>
            <div style={{ display: "flex", alignItems: "baseline", gap: 8, paddingBottom: i < graph.length - 1 ? 14 : 0 }}>
              <span style={{ fontSize: 13, fontFamily: "var(--font-family-code)",
                color: sp ? sp : (term ? "var(--color-text-tertiary)" : "var(--color-text-heading)") }}>{n.node}</span>
              <span style={{ fontSize: 11, color: "var(--color-text-quaternary)", fontFamily: "var(--font-family-code)" }}>+{n.ms}ms</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function Inspector({ agent, turn, turnIndex, onClose }) {
  if (!agent) return null;
  const empty = !turn || !turn.trace;
  const t = turn && turn.trace;
  return (
    <aside style={{
      width: 384, flex: "none", height: "100%", display: "flex", flexDirection: "column",
      background: "var(--color-bg-container)", borderLeft: "1px solid var(--color-border-secondary)",
    }}>
      <div style={{ flex: "none", padding: "14px 16px", borderBottom: "1px solid var(--color-border-secondary)",
        display: "flex", alignItems: "center", gap: 8 }}>
        <IN_Icon name="dashboard" size={16} style={{ color: "var(--color-text-secondary)" }} />
        <span style={{ fontSize: 14, fontWeight: 600, color: "var(--color-text-heading)", flex: 1 }}>턴 인스펙터</span>
        {!empty ? <IN_Tag color="blue">턴 {turnIndex + 1}</IN_Tag> : null}
        {onClose ? <IN_Button type="text" size="small" iconName="close" onClick={onClose} /> : null}
      </div>

      {empty ? (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
          gap: 10, color: "var(--color-text-tertiary)", padding: 24, textAlign: "center" }}>
          <IN_Icon name="thunderbolt" size={28} style={{ color: "var(--color-text-quaternary)" }} />
          <div style={{ fontSize: 13 }}>메시지를 보낸 뒤, 어시스턴트 턴을 선택하면<br />트레이스를 확인할 수 있습니다.</div>
        </div>
      ) : (
        <div style={{ flex: 1, overflowY: "auto" }}>
          {/* metrics strip */}
          <div style={{ display: "flex", gap: 0, padding: "12px 16px", borderBottom: "1px solid var(--color-border-secondary)" }}>
            <Metric label="지연시간" value={(t.latencyMs / 1000).toFixed(2) + "s"} />
            <Metric label="입력 토큰" value={t.tokens.in.toLocaleString()} />
            <Metric label="출력 토큰" value={t.tokens.out.toLocaleString()} />
          </div>

          <Section icon="file" iconColor="var(--color-primary)" title="시스템 프롬프트">
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <IN_Tag color="blue">{agent.name}</IN_Tag>
              {(agent.memories || []).map((m) => <IN_Tag key={m} color="purple">{m}</IN_Tag>)}
            </div>
            <pre style={codeBox}>{agent.systemPrompt}</pre>
          </Section>

          <Section icon="bulb" iconColor="var(--purple-6)" title="메모리" count={t.memories.length}>
            <div style={{ fontSize: 12, color: "var(--color-text-tertiary)" }}>메모리 타입: {(agent.memories || []).join(", ")}</div>
            {t.memories.map((m, i) => <MemoryRow key={i} m={m} />)}
          </Section>

          <Section icon="thunderbolt" iconColor="var(--cyan-7)" title="MCP 도구 호출" count={t.mcp.length}>
            {t.mcp.length ? t.mcp.map((c, i) => <McpCall key={i} c={c} />)
              : <div style={{ fontSize: 13, color: "var(--color-text-tertiary)" }}>호출된 도구 없음.</div>}
          </Section>

          <Section icon="share-alt" iconColor="var(--green-6)" title="LangGraph 경로" count={t.graph.length}>
            {t.resumedFrom ? <div style={{ fontSize: 12, color: "var(--purple-7)", marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}><IN_Icon name="clock-circle" size={12} />체크포인트에서 재개됨 <code style={{ fontFamily: "var(--font-family-code)" }}>{t.resumedFrom}</code></div> : null}
            <GraphPath graph={t.graph} />
          </Section>
        </div>
      )}
    </aside>
  );
}

function Metric({ label, value }) {
  return (
    <div style={{ flex: 1 }}>
      <div style={{ fontSize: 11, color: "var(--color-text-tertiary)" }}>{label}</div>
      <div style={{ fontSize: 16, fontWeight: 600, color: "var(--color-text-heading)", fontFamily: "var(--font-family-code)" }}>{value}</div>
    </div>
  );
}

window.Inspector = Inspector;
