/* my-agents admin — shared UI helpers used across views. */
const NS_SHARED = window.AntDesignSystem_b19dda;
const { Tag: SD_Tag, Icon: SD_Icon } = NS_SHARED;

/* Page padding wrapper with an optional toolbar (title + actions). */
window.Page = function Page({ title, subtitle, actions, children }) {
  return (
    <div style={{ padding: 24, maxWidth: 1200, margin: "0 auto" }}>
      {(title || actions) ? (
        <div style={{ display: "flex", alignItems: "flex-end", gap: 16, marginBottom: 20 }}>
          <div style={{ flex: 1 }}>
            {title ? <h3 style={{ fontSize: 20, margin: 0 }}>{title}</h3> : null}
            {subtitle ? <div style={{ color: "var(--color-text-tertiary)", marginTop: 4, fontSize: 14 }}>{subtitle}</div> : null}
          </div>
          {actions}
        </div>
      ) : null}
      {children}
    </div>
  );
};

/* Status pill: colored dot + label. */
window.StatusPill = function StatusPill({ color, label }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 7, fontSize: 14, color: "var(--color-text)" }}>
      <span style={{ width: 7, height: 7, borderRadius: "50%", background: color, flex: "none" }} />{label}
    </span>
  );
};

/* A bordered card surface (no DS Card header) for table panels. */
window.Panel = function Panel({ children, style }) {
  return (
    <div style={{ background: "var(--color-bg-container)", border: "1px solid var(--color-border-secondary)",
      borderRadius: "var(--radius-lg)", overflow: "hidden", ...style }}>{children}</div>
  );
};

/* Simple table. columns: [{key,title,width,render?,align?}], rows: any[]. */
window.Table = function Table({ columns, rows, onRowClick, rowKey = "id", empty = "데이터 없음" }) {
  return (
    <window.Panel>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
        <thead>
          <tr style={{ color: "var(--color-text-secondary)", textAlign: "left", background: "var(--gray-2)" }}>
            {columns.map((c) => (
              <th key={c.key} style={{ padding: "11px 16px", fontWeight: 500, width: c.width, textAlign: c.align || "left", whiteSpace: "nowrap" }}>{c.title}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr><td colSpan={columns.length} style={{ padding: "40px 16px", textAlign: "center", color: "var(--color-text-tertiary)" }}>{empty}</td></tr>
          ) : rows.map((r) => (
            <tr key={r[rowKey]}
              onClick={onRowClick ? () => onRowClick(r) : undefined}
              style={{ borderTop: "1px solid var(--color-border-secondary)", cursor: onRowClick ? "pointer" : "default" }}
              onMouseEnter={(e) => { if (onRowClick) e.currentTarget.style.background = "var(--color-fill-quaternary)"; }}
              onMouseLeave={(e) => { if (onRowClick) e.currentTarget.style.background = "transparent"; }}>
              {columns.map((c) => (
                <td key={c.key} style={{ padding: "13px 16px", textAlign: c.align || "left", color: "var(--color-text)" }}>
                  {c.render ? c.render(r) : r[c.key]}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </window.Panel>
  );
};

/* Right slide-over drawer. */
window.Drawer = function Drawer({ open, title, width = 480, onClose, footer, children }) {
  return (
    <div style={{ position: "absolute", inset: 0, zIndex: 1000, pointerEvents: open ? "auto" : "none" }}>
      <div onClick={onClose} style={{ position: "absolute", inset: 0, background: "var(--color-bg-mask)",
        opacity: open ? 1 : 0, transition: "opacity .25s" }} />
      <div style={{ position: "absolute", top: 0, right: 0, bottom: 0, width, maxWidth: "92%", background: "#fff",
        boxShadow: "var(--box-shadow)", display: "flex", flexDirection: "column",
        transform: open ? "translateX(0)" : "translateX(100%)", transition: "transform .25s cubic-bezier(.08,.82,.17,1)" }}>
        {open ? (
          <React.Fragment>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "16px 24px",
              borderBottom: "1px solid var(--color-border-secondary)", flex: "none" }}>
              <span style={{ fontSize: 16, fontWeight: 600 }}>{title}</span>
              <span onClick={onClose} style={{ cursor: "pointer", color: "var(--color-text-tertiary)" }}><SD_Icon name="close" /></span>
            </div>
            <div style={{ flex: 1, overflow: "auto", padding: 24 }}>{children}</div>
            {footer ? <div style={{ flex: "none", display: "flex", justifyContent: "flex-end", gap: 8, padding: 16,
              borderTop: "1px solid var(--color-border-secondary)" }}>{footer}</div> : null}
          </React.Fragment>
        ) : null}
      </div>
    </div>
  );
};

/* Key/value descriptor row. */
window.Desc = function Desc({ label, children, width = 120 }) {
  return (
    <div style={{ display: "flex", alignItems: "flex-start", padding: "10px 0", borderBottom: "1px solid var(--color-border-secondary)", fontSize: 14 }}>
      <div style={{ width, color: "var(--color-text-tertiary)", flex: "none", paddingTop: 1 }}>{label}</div>
      <div style={{ color: "var(--color-text)", flex: 1, minWidth: 0, display: "flex", flexWrap: "wrap", gap: 6, alignItems: "center" }}>{children}</div>
    </div>
  );
};

/* Version-history list with lifecycle actions. Shared by agents and MCP servers.
   onActivate(version) promotes a draft/archived version to active;
   onTest(version) opens a draft for testing; onNewDraft() forks a new draft. */
window.VersionHistory = function VersionHistory({ versions = [], onActivate, onTest, onNewDraft, onRevert }) {
  const { Tag, Icon, Button } = window.AntDesignSystem_b19dda;
  const VS = window.VERSION_STATUS;
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", marginBottom: 10 }}>
        <span style={{ fontSize: 13, fontWeight: 600, color: "var(--color-text-heading)", flex: 1 }}>버전</span>
        {onNewDraft ? <Button type="dashed" size="small" iconName="plus" onClick={onNewDraft}>새 초안</Button> : null}
      </div>
      <div style={{ border: "1px solid var(--color-border-secondary)", borderRadius: "var(--radius-lg)", overflow: "hidden" }}>
        {versions.map((v, i) => {
          const st = VS[v.status] || VS.archived;
          return (
            <div key={v.version} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px",
              borderTop: i ? "1px solid var(--color-border-secondary)" : "none",
              background: v.status === "active" ? "var(--color-success-bg)" : v.status === "draft" ? "var(--gold-1)" : "transparent" }}>
              <code style={{ fontFamily: "var(--font-family-code)", fontSize: 13, fontWeight: 600, color: "var(--color-text-heading)", width: 34 }}>{v.version}</code>
              <Tag color={st.tag}>{st.label}</Tag>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, color: "var(--color-text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{v.note}</div>
                <div style={{ fontSize: 11, color: "var(--color-text-tertiary)" }}>{v.createdAt}</div>
              </div>
              {v.status === "draft" && onTest ? <Button type="primary" size="small" iconName="thunderbolt" onClick={() => onTest(v)}>테스트</Button> : null}
              {v.status !== "active" && onActivate ? <Button size="small" iconName="check" onClick={() => onActivate(v)}>활성화</Button> : null}
              {v.status !== "draft" && onRevert ? <Button type="text" size="small" iconName="redo" onClick={() => onRevert(v)} title="초안으로 되돌리기" /> : null}
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* Expose on/off switch with a label. */
window.ExposeSwitch = function ExposeSwitch({ on, onChange, label, onText = "공개", offText = "비공개", accent = "var(--color-success)" }) {
  const { Switch, Tag } = window.AntDesignSystem_b19dda;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px 14px", border: "1px solid var(--color-border-secondary)", borderRadius: "var(--radius-lg)", background: "var(--gray-2)" }}>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 14, fontWeight: 500, color: "var(--color-text-heading)" }}>{label}</div>
        <div style={{ fontSize: 12, color: "var(--color-text-tertiary)" }}>{on ? onText : offText}</div>
      </div>
      <Switch checked={on} onChange={onChange} />
    </div>
  );
};
