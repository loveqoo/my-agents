/* my-agents admin — Building blocks (재료) browser: personas, memory policies,
   permissions, MCP servers. Category tabs → list → detail drawer. */
const NS_BV = window.AntDesignSystem_b19dda;
const { Tag: BV_Tag, Icon: BV_Icon, Button: BV_Button, Tabs: BV_Tabs, Switch: BV_Switch, Modal: BV_Modal, Input: BV_Input, Select: BV_Select, Checkbox: BV_Checkbox, Alert: BV_Alert } = NS_BV;

const MCP_STATUS = {
  connected: { tag: "green", label: "Connected" },
  degraded: { tag: "gold", label: "Degraded" },
  disconnected: { tag: "red", label: "Disconnected" },
};

/* MCP register/edit connection form. mode: "register" (new) | "edit". */
function McpForm({ form, onCancel, onSave }) {
  const external = form && (form.source === "external" || (form.item && form.item.source === "external"));
  const blank = { name: "", transport: external ? "http" : "stdio", url: "", auth: "None", tools: [], enabledTools: [] };
  const [f, setF] = React.useState(blank);
  React.useEffect(() => {
    if (!form) return;
    if (form.mode === "edit") { const m = form.item; setF({ ...m, tools: [...m.tools], enabledTools: [...(m.enabledTools || m.tools)] }); }
    else setF({ ...blank, transport: external ? "http" : "stdio" });
    /* eslint-disable-next-line */
  }, [form]);
  if (!form) return null;
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  const toggleTool = (t) => setF((s) => ({ ...s, enabledTools: s.enabledTools.includes(t) ? s.enabledTools.filter((x) => x !== t) : [...s.enabledTools, t] }));
  const isExternal = external;
  const isEdit = form.mode === "edit";

  const submit = () => {
    const id = isEdit ? f.id : "mcp-" + Date.now();
    const tools = isEdit ? f.tools : (f.toolsText || "").split(",").map((x) => x.trim()).filter(Boolean);
    const enabledTools = isEdit ? f.enabledTools : tools;
    const item = {
      id, name: f.name.trim() || (isExternal ? "external-mcp" : "new-server"),
      source: isExternal ? "external" : "local", transport: f.transport,
      tools, enabledTools, usedBy: isEdit ? f.usedBy : 0, status: "connected", updated: "just now",
      published: isEdit ? !!f.published : false,
      url: isExternal ? (f.url || "mcp://remote/endpoint") : undefined,
      auth: isExternal ? f.auth : undefined,
      endpoint: isExternal ? undefined : (f.endpoint || ("mcp://my-agents.local/" + (f.name.trim() || "new-server"))),
    };
    onSave(item);
  };

  return (
    <BV_Modal open={!!form} width={520}
      title={isEdit ? "연결 편집 · " + f.name : (isExternal ? "외부 MCP 등록" : "새 로컬 MCP 서버")}
      okText={isEdit ? "연결 저장" : "등록"} cancelText="취소" onCancel={onCancel} onOk={submit}>
      <div style={{ display: "flex", flexDirection: "column", gap: 16, maxHeight: "60vh", overflow: "auto" }}>
        <BV_Alert type="info" showIcon style={{ marginBottom: 0 }}
          message={isExternal
            ? "다른 곳에서 프로토콜로 공개한 MCP 서버에 연결합니다. 그 도구를 소비합니다."
            : "직접 운영하는 서버를 등록합니다. 나중에 MCP로 외부 공개할 수 있습니다."} />
        <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <span style={{ fontSize: 14, fontWeight: 500 }}>이름</span>
          <BV_Input placeholder={isExternal ? "예: partner-crm" : "예: filesystem"} value={f.name} onChange={(e) => set("name", e.target.value)} />
        </label>
        {isExternal ? (
          <React.Fragment>
            <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              <span style={{ fontSize: 14, fontWeight: 500 }}>MCP URL</span>
              <BV_Input prefixIcon="global" placeholder="mcp://host/endpoint" value={f.url} onChange={(e) => set("url", e.target.value)} />
            </label>
            <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              <span style={{ fontSize: 14, fontWeight: 500 }}>인증</span>
              <BV_Select value={f.auth} onChange={(v) => set("auth", v)} options={[
                { label: "없음", value: "None" }, { label: "Bearer 토큰", value: "Bearer ****" }, { label: "OAuth", value: "OAuth" }]} />
            </label>
          </React.Fragment>
        ) : (
          <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <span style={{ fontSize: 14, fontWeight: 500 }}>전송 방식</span>
            <BV_Select value={f.transport} onChange={(v) => set("transport", v)} options={[
              { label: "stdio", value: "stdio" }, { label: "http", value: "http" }]} />
          </label>
        )}
        {isEdit ? (
          <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <span style={{ fontSize: 14, fontWeight: 500 }}>활성 도구</span>
            <div style={{ display: "flex", flexWrap: "wrap", gap: "8px 16px" }}>
              {f.tools.map((t) => <BV_Checkbox key={t} checked={f.enabledTools.includes(t)} onChange={() => toggleTool(t)}>{t}</BV_Checkbox>)}
            </div>
          </label>
        ) : (
          <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <span style={{ fontSize: 14, fontWeight: 500 }}>도구 <span style={{ color: "var(--color-text-tertiary)", fontWeight: 400 }}>(쉼표로 구분{isExternal ? "; 서버에서 자동 발견" : ""})</span></span>
            <BV_Input placeholder="search, read, list" value={f.toolsText || ""} onChange={(e) => set("toolsText", e.target.value)} />
          </label>
        )}
      </div>
    </BV_Modal>
  );
}

function BlocksView() {
  const [data, setData] = React.useState(window.BLOCKS);
  const [cat, setCat] = React.useState("persona");
  const [detail, setDetail] = React.useState(null);
  const [mcpForm, setMcpForm] = React.useState(null); // { mode:'register'|'edit', item? }
  const def = data[cat];

  const togglePublish = (id) => {
    setData((d) => ({ ...d, mcp: { ...d.mcp, items: d.mcp.items.map((m) => m.id === id ? { ...m, published: !m.published } : m) } }));
    setDetail((dt) => dt && dt.id === id ? { ...dt, published: !dt.published } : dt);
  };
  const upsertMcp = (item) => {
    setData((d) => {
      const exists = d.mcp.items.find((m) => m.id === item.id);
      const items = exists ? d.mcp.items.map((m) => m.id === item.id ? item : m) : [item, ...d.mcp.items];
      return { ...d, mcp: { ...d.mcp, items } };
    });
    setDetail((dt) => dt && dt.id === item.id ? item : dt);
    setMcpForm(null);
  };

  const colsFor = (key) => {
    if (key === "mcp") return [
      { key: "name", title: "서버", render: (r) => (
        <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
          <code style={{ fontFamily: "var(--font-family-code)", color: "var(--cyan-7)", fontSize: 13 }}>{r.name}</code>
          <BV_Tag color={r.source === "external" ? "purple" : "default"}>{r.source === "external" ? "외부" : "로컬"}</BV_Tag>
        </span>) },
      { key: "transport", title: "전송", width: 100, render: (r) => <BV_Tag>{r.transport}</BV_Tag> },
      { key: "tools", title: "도구", render: (r) => <span style={{ display: "inline-flex", gap: 4, flexWrap: "wrap" }}>{r.tools.map((t) => <BV_Tag key={t} color={(r.enabledTools || r.tools).includes(t) ? "geekblue" : "default"}>{t}</BV_Tag>)}</span> },
      { key: "status", title: "상태", width: 110, render: (r) => { const s = MCP_STATUS[r.status]; return <BV_Tag color={s.tag}>{s.label}</BV_Tag>; } },
      { key: "published", title: "공개", width: 116, render: (r) => r.source === "external"
        ? <span style={{ color: "var(--color-text-quaternary)" }}>—</span>
        : (r.published ? <BV_Tag color="green">MCP · 공개</BV_Tag> : <span style={{ color: "var(--color-text-quaternary)" }}>비공개</span>) },
      { key: "usedBy", title: "사용", width: 70, align: "right", render: (r) => <span style={{ color: "var(--color-text-secondary)" }}>{r.usedBy}</span> },
    ];
    if (key === "embedding") return [
      { key: "name", title: "테이블", render: (r) => <code style={{ fontFamily: "var(--font-family-code)", color: "var(--cyan-7)", fontSize: 13 }}>{r.name}</code> },
      { key: "model", title: "임베딩 모델", render: (r) => <BV_Tag color="geekblue">{r.model}</BV_Tag> },
      { key: "source", title: "출처", render: (r) => <code style={{ fontFamily: "var(--font-family-code)", fontSize: 12, color: "var(--color-text-secondary)" }}>{r.source}</code> },
      { key: "rows", title: "행", width: 90, align: "right", render: (r) => <span style={{ fontFamily: "var(--font-family-code)", color: "var(--color-text-secondary)" }}>{r.rows.toLocaleString()}</span> },
      { key: "status", title: "상태", width: 110, render: (r) => { const s = window.VECTOR_STATUS[r.status]; return <BV_Tag color={s.tag}>{s.label}</BV_Tag>; } },
      { key: "usedBy", title: "사용", width: 70, align: "right", render: (r) => <span style={{ color: "var(--color-text-secondary)" }}>{r.usedBy}</span> },
    ];
    if (key === "permission") return [
      { key: "name", title: "권한", render: (r) => <code style={{ fontFamily: "var(--font-family-code)", color: "var(--geekblue-7)", fontSize: 13 }}>{r.name}</code> },
      { key: "scope", title: "범위", width: 130, render: (r) => <BV_Tag>{r.scope}</BV_Tag> },
      { key: "approver", title: "승인자", width: 120, render: (r) => { const a = window.APPROVER[r.approver]; return <BV_Tag color={a.tag}><span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><BV_Icon name={a.icon} size={11} />{a.label}</span></BV_Tag>; } },
      { key: "body", title: "설명", render: (r) => <span style={{ color: "var(--color-text-secondary)" }}>{r.body}</span> },
      { key: "usedBy", title: "사용", width: 80, align: "right", render: (r) => <span style={{ color: "var(--color-text-secondary)" }}>{r.usedBy}</span> },
    ];
    // persona + memory
    return [
      { key: "name", title: def.label.replace(/s$/, ""), render: (r) => <span style={{ fontWeight: 500, color: "var(--color-text-heading)" }}>{r.name}</span> },
      { key: "meta", title: key === "persona" ? "톤" : "범위", width: 200, render: (r) => <BV_Tag color={key === "persona" ? "magenta" : "purple"}>{r.tone || r.scope}</BV_Tag> },
      { key: "usedBy", title: "사용", width: 100, render: (r) => <span style={{ color: "var(--color-text-secondary)" }}>{r.usedBy}개 에이전트</span> },
      { key: "updated", title: "수정", width: 120, align: "right", render: (r) => <span style={{ color: "var(--color-text-tertiary)" }}>{r.updated}</span> },
    ];
  };

  const tabItems = Object.keys(data).map((k) => ({
    key: k,
    label: (
      <span style={{ display: "inline-flex", alignItems: "center", gap: 7 }}>
        <BV_Icon name={data[k].icon} size={14} style={{ color: data[k].color }} />
        {data[k].label}
        <BV_Tag>{data[k].items.length}</BV_Tag>
      </span>
    ),
  }));

  return (
    <window.Page title="빌딩 블록" subtitle="에이전트를 구성하는 재사용 재료 — 둘러보고 에이전트 편집기에서 조립하세요"
      actions={cat === "mcp"
        ? <span style={{ display: "inline-flex", gap: 8 }}>
            <BV_Button iconName="global" onClick={() => setMcpForm({ mode: "register", source: "external" })}>외부 등록</BV_Button>
            <BV_Button type="primary" iconName="plus" onClick={() => setMcpForm({ mode: "register", source: "local" })}>새 서버</BV_Button>
          </span>
        : <BV_Button type="primary" iconName="plus">새 항목</BV_Button>}>
      <BV_Tabs activeKey={cat} onChange={(k) => { setCat(k); setDetail(null); }} items={tabItems} />
      <div style={{ marginTop: 4, marginBottom: 14, color: "var(--color-text-tertiary)", fontSize: 14 }}>{def.desc}</div>
      <window.Table columns={colsFor(cat)} rows={def.items} onRowClick={setDetail} />

      <window.Drawer open={!!detail} title={detail ? detail.name : ""} width={440} onClose={() => setDetail(null)}
        footer={<React.Fragment>
          <BV_Button danger iconName="delete">삭제</BV_Button>
          {cat === "mcp"
            ? <BV_Button type="primary" iconName="edit" onClick={() => setMcpForm({ mode: "edit", item: detail })}>연결 편집</BV_Button>
            : <BV_Button type="primary" iconName="edit">편집</BV_Button>}
        </React.Fragment>}>
        {detail ? (
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
              <span style={{ width: 36, height: 36, borderRadius: 9, background: def.color, color: "#fff",
                display: "inline-flex", alignItems: "center", justifyContent: "center" }}><BV_Icon name={def.icon} size={18} /></span>
              <div style={{ fontSize: 16, fontWeight: 600 }}>{detail.name}</div>
            </div>
            {detail.model ? <window.Desc label="임베딩 모델"><BV_Tag color="geekblue">{detail.model}</BV_Tag></window.Desc> : null}
            {detail.source ? <window.Desc label="출처"><code style={{ fontFamily: "var(--font-family-code)", fontSize: 12 }}>{detail.source}</code></window.Desc> : null}
            {detail.dims ? <window.Desc label="차원">{detail.dims.toLocaleString()}차원</window.Desc> : null}
            {detail.rows != null ? <window.Desc label="행 수">{detail.rows.toLocaleString()}개 벡터</window.Desc> : null}
            {detail.status && window.VECTOR_STATUS[detail.status] ? <window.Desc label="상태"><BV_Tag color={window.VECTOR_STATUS[detail.status].tag}>{window.VECTOR_STATUS[detail.status].label}</BV_Tag></window.Desc> : null}
            {detail.tone ? <window.Desc label="톤"><BV_Tag color="magenta">{detail.tone}</BV_Tag></window.Desc> : null}
            {detail.scope ? <window.Desc label="범위"><BV_Tag color={cat === "memory" ? "purple" : "default"}>{detail.scope}</BV_Tag></window.Desc> : null}
            {detail.approver ? (() => { const a = window.APPROVER[detail.approver]; return (
              <window.Desc label="승인자">
                <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
                  <BV_Tag color={a.tag}><span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><BV_Icon name={a.icon} size={11} />{a.label}</span></BV_Tag>
                  <span style={{ fontSize: 12, color: "var(--color-text-tertiary)" }}>{a.desc}</span>
                </span>
              </window.Desc>); })() : null}
            {detail.transport ? <window.Desc label="전송"><BV_Tag>{detail.transport}</BV_Tag></window.Desc> : null}
            {cat === "mcp" && detail.source ? <window.Desc label="소스"><BV_Tag color={detail.source === "external" ? "purple" : "default"}>{detail.source === "external" ? "외부 · URL로 등록" : "로컬 · 자체 운영"}</BV_Tag></window.Desc> : null}
            {detail.url ? <window.Desc label="URL"><code style={{ fontFamily: "var(--font-family-code)", fontSize: 12, wordBreak: "break-all" }}>{detail.url}</code></window.Desc> : null}
            {detail.auth ? <window.Desc label="인증"><BV_Tag>{detail.auth}</BV_Tag></window.Desc> : null}
            {detail.tools ? <window.Desc label="도구"><span style={{ display: "inline-flex", gap: 4, flexWrap: "wrap" }}>{detail.tools.map((t) => <BV_Tag key={t} color={(detail.enabledTools || detail.tools).includes(t) ? "geekblue" : "default"}>{t}{(detail.enabledTools && !detail.enabledTools.includes(t)) ? " (귫)" : ""}</BV_Tag>)}</span></window.Desc> : null}
            {cat === "mcp" && detail.status ? <window.Desc label="상태"><BV_Tag color={MCP_STATUS[detail.status].tag}>{MCP_STATUS[detail.status].label}</BV_Tag></window.Desc> : null}
            <window.Desc label="사용">{detail.usedBy}개 에이전트</window.Desc>
            <window.Desc label="수정">{detail.updated}</window.Desc>
            {cat === "mcp" && detail.source !== "external" ? (
              <div style={{ marginTop: 18, padding: 16, border: "1px solid var(--color-border-secondary)", borderRadius: "var(--radius-lg)", background: "var(--gray-2)" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <BV_Icon name="global" size={16} style={{ color: "var(--cyan-7)" }} />
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 500 }}>외부 공개</div>
                    <div style={{ fontSize: 12, color: "var(--color-text-tertiary)" }}>이 서버의 도구를 LangGraph MCP 프로토콜로 노출합니다</div>
                  </div>
                  <BV_Switch checked={detail.published} onChange={() => togglePublish(detail.id)} />
                </div>
                {detail.published ? (
                  <div style={{ marginTop: 12, display: "flex", alignItems: "center", gap: 8 }}>
                    <BV_Tag color="green">public</BV_Tag>
                    <code style={{ fontFamily: "var(--font-family-code)", fontSize: 12, color: "var(--color-text-secondary)", flex: 1, overflow: "hidden", textOverflow: "ellipsis" }}>{detail.endpoint}</code>
                    <BV_Button type="text" size="small" iconName="copy" onClick={() => navigator.clipboard && navigator.clipboard.writeText(detail.endpoint)} />
                  </div>
                ) : null}
              </div>
            ) : null}
            {cat === "mcp" && detail.source === "external" ? (
              <div style={{ marginTop: 18 }}>
                <BV_Alert type="info" showIcon message="외부 MCP — 다른 곳에서 호스팅·공개한 서버의 도구를 소비합니다." />
              </div>
            ) : null}
            {detail.body ? (
              <div style={{ marginTop: 16 }}>
                <div style={{ fontSize: 12, color: "var(--color-text-tertiary)", marginBottom: 6 }}>정의</div>
                <pre style={{ fontFamily: "var(--font-family-code)", fontSize: 12, lineHeight: 1.6, color: "var(--color-text)",
                  background: "var(--gray-2)", border: "1px solid var(--color-border-secondary)", borderRadius: 8, padding: "12px 14px",
                  margin: 0, whiteSpace: "pre-wrap" }}>{detail.body}</pre>
              </div>
            ) : null}
          </div>
        ) : null}
      </window.Drawer>
      <McpForm form={mcpForm} onCancel={() => setMcpForm(null)} onSave={upsertMcp} />
    </window.Page>
  );
}

window.BlocksView = BlocksView;
