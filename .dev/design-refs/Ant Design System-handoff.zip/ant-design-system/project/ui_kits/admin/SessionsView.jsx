/* my-agents admin — Sessions view: live & past conversation sessions, each with
   status; click a session to see its state detail. */
const NS_SV = window.AntDesignSystem_b19dda;
const { Tag: SV_Tag, Icon: SV_Icon, Button: SV_Button, Avatar: SV_Avatar, Alert: SV_Alert, RadioGroup: SV_Radio } = NS_SV;

function SessionsView() {
  const all = window.ADMIN_SESSIONS;
  const [filter, setFilter] = React.useState("all");
  const [detail, setDetail] = React.useState(null);

  const rows = filter === "all" ? all
    : filter === "live" ? all.filter((s) => s.status === "active" || s.status === "running" || s.status === "draining")
    : all.filter((s) => s.status === filter);

  const columns = [
    { key: "id", title: "세션", render: (s) => (
      <div>
        <code style={{ fontFamily: "var(--font-family-code)", fontSize: 13, color: "var(--color-text-heading)" }}>{s.id}</code>
        <div style={{ fontSize: 12, color: "var(--color-text-tertiary)" }}>{s.channel}</div>
      </div>) },
    { key: "agent", title: "에이전트", render: (s) => (
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <SV_Avatar size="small" style={{ background: "var(--gray-12)" }}><SV_Icon name="robot" size={13} /></SV_Avatar>
        <span>{s.agent}</span>
      </div>) },
    { key: "status", title: "상태", width: 130, render: (s) => {
      const st = window.SESSION_STATUS[s.status];
      return s.status === "running"
        ? <span style={{ display: "inline-flex", alignItems: "center", gap: 7, fontSize: 14 }}><SV_Icon name="loading" spin size={13} style={{ color: st.color }} />{st.label}</span>
        : <window.StatusPill color={st.color} label={st.label} />; } },
    { key: "turns", title: "턴", width: 80, align: "right", render: (s) => <span style={{ fontFamily: "var(--font-family-code)" }}>{s.turns}</span> },
    { key: "tokens", title: "토큰", width: 100, align: "right", render: (s) => <span style={{ fontFamily: "var(--font-family-code)", color: "var(--color-text-secondary)" }}>{(s.tokens / 1000).toFixed(1)}k</span> },
    { key: "lastActivity", title: "마지막 활동", width: 140, align: "right", render: (s) => <span style={{ color: "var(--color-text-tertiary)" }}>{s.lastActivity}</span> },
  ];

  const counts = {
    all: all.length,
    live: all.filter((s) => s.status === "active" || s.status === "running").length,
    awaiting: all.filter((s) => s.status === "awaiting").length,
    error: all.filter((s) => s.status === "error").length,
  };

  return (
    <window.Page title="세션" subtitle="모든 채널에서 에이전트와 진행 중인 대화">
      <div style={{ marginBottom: 16 }}>
        <SV_Radio optionType="button" value={filter} onChange={setFilter} options={[
          { label: `전체 (${counts.all})`, value: "all" },
          { label: `라이브 (${counts.live})`, value: "live" },
          { label: `승인 대기 (${counts.awaiting})`, value: "awaiting" },
          { label: `오류 (${counts.error})`, value: "error" },
        ]} />
      </div>
      <window.Table columns={columns} rows={rows} onRowClick={setDetail} empty="조건에 맞는 세션이 없습니다" />

      <window.Drawer open={!!detail} title={detail ? detail.id : ""} width={440} onClose={() => setDetail(null)}
        footer={detail && (detail.status === "active" || detail.status === "running" || detail.status === "idle")
          ? <React.Fragment>
              <SV_Button onClick={() => setDetail(null)}>닫기</SV_Button>
              <SV_Button danger iconName="pause-circle">세션 종료</SV_Button>
            </React.Fragment>
          : <SV_Button onClick={() => setDetail(null)}>닫기</SV_Button>}>
        {detail ? (
          <div>
            {(() => { const st = window.SESSION_STATUS[detail.status]; return (
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
                <span style={{ width: 10, height: 10, borderRadius: "50%", background: st.color }} />
                <span style={{ fontSize: 16, fontWeight: 600 }}>{st.label}</span>
                <SV_Tag color={st.tag} style={{ marginInlineStart: "auto" }}>{detail.channel}</SV_Tag>
              </div>); })()}
            {detail.error ? <div style={{ marginBottom: 16 }}><SV_Alert type="error" showIcon message="세션 오류" description={detail.error} /></div> : null}
            {detail.awaiting ? <div style={{ marginBottom: 16 }}><SV_Alert type="warning" showIcon message="일시정지 — 관리자 승인 대기 중"
              description={`${detail.awaiting.summary} · ${detail.awaiting.permission} · 체크포인트 ${detail.awaiting.checkpoint}`} /></div> : null}
            <window.Desc label="에이전트">{detail.agent}</window.Desc>
            <window.Desc label="채널">{detail.channel}</window.Desc>
            <window.Desc label="턴">{detail.turns}</window.Desc>
            <window.Desc label="토큰">{detail.tokens.toLocaleString()}</window.Desc>
            <window.Desc label="시작">{detail.started}</window.Desc>
            <window.Desc label="마지막 활동">{detail.lastActivity}</window.Desc>
            <div style={{ marginTop: 16 }}>
              <SV_Alert type="info" showIcon message="디버그 콘솔에서 이 세션을 열면 턴별 프롬프트·메모리·MCP 호출을 확인할 수 있습니다." />
            </div>
          </div>
        ) : null}
      </window.Drawer>
    </window.Page>
  );
}

window.SessionsView = SessionsView;
