/* my-agents admin — Approvals queue: admin-approver permission requests where a
   LangGraph run is paused at a checkpoint (interrupt) awaiting an admin decision.
   Approve → resume from checkpoint; Reject → abort the run. */
const NS_AP = window.AntDesignSystem_b19dda;
const { Tag: AP_Tag, Icon: AP_Icon, Button: AP_Button, Avatar: AP_Avatar, Alert: AP_Alert, Modal: AP_Modal } = NS_AP;

function ApprovalCard({ item, onResolve }) {
  const [busy, setBusy] = React.useState(null); // "approve" | "reject"
  const act = (decision) => { setBusy(decision); setTimeout(() => onResolve(item, decision), 360); };
  return (
    <window.Panel style={{ padding: 0 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "14px 18px", borderBottom: "1px solid var(--color-border-secondary)" }}>
        <AP_Avatar size="small" style={{ background: "var(--gray-12)" }}><AP_Icon name="robot" size={13} /></AP_Avatar>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 500, color: "var(--color-text-heading)" }}>{item.agent}</div>
          <div style={{ fontSize: 12, color: "var(--color-text-tertiary)" }}>
            <code style={{ fontFamily: "var(--font-family-code)" }}>{item.sessionId}</code> · {item.requestedAt}
          </div>
        </div>
        <AP_Tag color="purple"><span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><AP_Icon name="team" size={11} />관리자 승인</span></AP_Tag>
      </div>

      <div style={{ padding: "16px 18px" }}>
        <div style={{ fontSize: 15, fontWeight: 500, color: "var(--color-text-heading)", marginBottom: 10 }}>{item.summary}</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12 }}>
          <AP_Tag color="geekblue">{item.permission}</AP_Tag>
          <AP_Tag color="cyan"><code style={{ fontFamily: "var(--font-family-code)" }}>{item.action}</code></AP_Tag>
        </div>
        <div style={{ fontSize: 12, color: "var(--color-text-tertiary)", marginBottom: 4 }}>인자</div>
        <pre style={{ fontFamily: "var(--font-family-code)", fontSize: 12, lineHeight: 1.6, color: "var(--color-text)",
          background: "var(--gray-2)", border: "1px solid var(--color-border-secondary)", borderRadius: 6, padding: "10px 12px", margin: 0, whiteSpace: "pre-wrap" }}>
          {JSON.stringify(item.args, null, 2)}
        </pre>
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 12, fontSize: 12, color: "var(--color-text-tertiary)" }}>
          <AP_Icon name="clock-circle" size={12} />
          체크포인트 <code style={{ fontFamily: "var(--font-family-code)", color: "var(--color-text-secondary)" }}>{item.checkpoint}</code>에서 일시정지됨 — 승인하면 여기서 재개됩니다.
        </div>
      </div>

      <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, padding: "0 18px 16px" }}>
        <AP_Button danger iconName="close" loading={busy === "reject"} disabled={!!busy} onClick={() => act("reject")}>거부</AP_Button>
        <AP_Button type="primary" iconName="check" loading={busy === "approve"} disabled={!!busy} onClick={() => act("approve")}>승인 및 재개</AP_Button>
      </div>
    </window.Panel>
  );
}

function ApprovalsView() {
  const [queue, setQueue] = React.useState(window.ADMIN_APPROVALS);
  const [toast, setToast] = React.useState(null);
  React.useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(null), 2600); return () => clearTimeout(t); }, [toast]);

  const resolve = (item, decision) => {
    setQueue((q) => q.filter((x) => x.id !== item.id));
    window.ADMIN_APPROVALS = window.ADMIN_APPROVALS.filter((x) => x.id !== item.id);
    setToast(decision === "approve"
      ? { type: "success", msg: `승인됨 — ${item.checkpoint}에서 ${item.agent} 재개 중` }
      : { type: "warning", msg: `거부됨 — ${item.agent} 실행 중단` });
  };

  return (
    <window.Page title="승인" subtitle="체크포인트에서 일시정지된 관리자 승인 작업 — 결정을 기다립니다">
      {queue.length === 0 ? (
        <window.Panel style={{ padding: "56px 24px", textAlign: "center", color: "var(--color-text-tertiary)" }}>
          <AP_Icon name="check-circle" size={30} style={{ color: "var(--color-success)" }} />
          <div style={{ marginTop: 10, fontSize: 14 }}>대기 중인 승인이 없습니다. 모두 처리됐어요.</div>
        </window.Panel>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, alignItems: "start" }}>
          {queue.map((item) => <ApprovalCard key={item.id} item={item} onResolve={resolve} />)}
        </div>
      )}

      {toast ? (
        <div style={{ position: "absolute", top: 16, left: 0, right: 0, display: "flex", justifyContent: "center", zIndex: 1100, pointerEvents: "none" }}>
          <div style={{ pointerEvents: "auto" }}><AP_Alert type={toast.type} showIcon message={toast.msg} /></div>
        </div>
      ) : null}
    </window.Page>
  );
}

window.ApprovalsView = ApprovalsView;
