# Admin UI Kit — `my-agents` management console

A management console for **my-agents**, a personal service for composing and running
LangChain / LangGraph agents. Built from this design system's antd + Ant Design X
primitives. Pairs with the **agent debug console** (`ui_kits/agent-debug/`).

## Run
Open [`index.html`](index.html).

## Views
1. **Overview** — counts (agents, building blocks, live sessions, exposed agents)
   with quick links, plus recent-agents and live-sessions panels.
2. **Agents** — table of every composed agent (persona, MCP servers, exposure,
   status). Full **CRUD**:
   - **Create / Edit** — a modal form that *composes building blocks*: name, model,
     persona, memory policy, permission checkboxes, MCP-server checkboxes, and an
     **A2A** exposure switch (publish the agent as an A2A endpoint).
   - **Detail** — click a row for a drawer with the full config.
   - **Delete** — confirm dialog; success toasts on every mutation.
3. **Building blocks (재료)** — browse the reusable materials agents are made of,
   in four category tabs: **Personas**, **Memory policies**, **Permissions**,
   **MCP servers**. Each row opens a detail drawer (definition, scope/transport,
   tools, usage count, status). **MCP servers** additionally have a **Publish**
   toggle that exposes their tools over the LangGraph MCP protocol, with a copyable
   endpoint.
4. **Sessions** — every conversation running against your agents, across channels
   (debug-console, A2A, github-webhook, web-chat). Filter All / Live / Errors;
   each row shows **status** (active · running · idle · error · completed), turns,
   tokens and last activity. Click for a status detail drawer (with error reason
   and a terminate action for live sessions).

## Exposure model

- **Agents** are exposed conversationally via the **A2A** protocol (one switch per
  agent). An agent always uses its own MCP tools *internally* — that's not an
  exposure.
- **MCP servers** (building blocks) are published independently over the LangGraph
  **MCP** protocol via the Publish toggle in their detail drawer.

The `exposed` object on each agent keeps an object shape (`{ a2a }`) so advanced
patterns (e.g. publishing an agent itself as an MCP tool) can be added later
without reworking the UI.

## Versioning & exposure
Both **Agents** and **MCP servers** are versioned and individually exposable:
- **Edit always writes to a draft.** Every version carries an editable config
  snapshot (model · persona · memory · permissions · MCP). Editing an agent never
  touches the live version — it creates or updates a **draft** while the **active**
  version keeps serving. The detail drawer shows the active config plus a draft
  panel summarizing what the draft changes.
- **Test → Activate → Revert.** Test a draft in the debug console, then **Activate**
  to publish (its config is promoted to active; the previous active is archived).
  **Revert** an active version back to draft to roll back — the most recent archived
  version is restored to active. New agents start as a **v1 draft**.
- **Expose / register over MCP** — a **local** MCP server can be **published** over
  the protocol (publish toggle + endpoint); an **external** MCP (one someone else
  published) can be **registered by URL** (with transport + auth) so your agents can
  consume its tools. MCP servers have a plain **Edit connection** (transport,
  endpoint, enabled tools) — no draft/version lifecycle.
- **Expose on/off (agents)** — an Agent toggles **A2A** exposure (inline switch in
  the list and detail). When exposed it shows its **A2A identity** — Agent ID, A2A
  endpoint, and Agent Card URL — to share with consumers. Turning A2A **off while it
  has live sessions** opens a safeguard dialog: **Deprecate (drain)** — stop new
  sessions, let running ones finish (they move to a `draining` state) — or **Revoke
  now** — cut the endpoint immediately and terminate sessions.

## Files
- `index.html` — shell + loader (also a Starting Point).
- `adminData.js` — building blocks, agents, and sessions data.
- `adminShared.jsx` — shared helpers (Page, Table, Panel, Drawer, StatusPill, Desc).
- `OverviewView.jsx` · `AgentsView.jsx` · `BlocksView.jsx` · `SessionsView.jsx`.
- `AdminShell.jsx` — navy sider + header + view router.

## Components exercised
`Menu`, `Tabs`, `Modal`, `Select`, `Input`, `Checkbox`, `Switch`, `RadioGroup`,
`Tag`, `Avatar`, `Badge`, `Alert`, `Button`, `Icon`. Tables, drawers and the stat
tiles are bespoke surfaces built on the same tokens.

All data is local/in-memory; CRUD mutates React state. Wire `adminData.js` to your
LangGraph backend to make it live.
