/* my-agents admin — app shell: navy sider + header + view router. */
const NS_SH = window.AntDesignSystem_b19dda;
const { Menu: SH_Menu, Icon: SH_Icon, Input: SH_Input, Avatar: SH_Avatar, Badge: SH_Badge, Button: SH_Button } = NS_SH;

function AdminShell() {
  const [view, setView] = React.useState("agents");
  const [collapsed, setCollapsed] = React.useState(false);

  const sessions = window.ADMIN_SESSIONS;
  const liveCount = sessions.filter((s) => s.status === "active" || s.status === "running").length;

  const titles = {
    overview: "개요",
    agents: "에이전트",
    blocks: "빌딩 블록",
    sessions: "세션",
    approvals: "승인",
    debug: "Playground",
  };

  // Full-app views embedded as iframes (their own React roots).
  const embeds = { debug: "../agent-debug/index.html" };
  const isEmbed = !!embeds[view];

  const pendingApprovals = (window.ADMIN_APPROVALS || []).length;

  return (
    <div style={{ height: "100%", display: "flex", background: "var(--color-bg-layout)" }}>
      {/* Sider */}
      <aside style={{ width: collapsed ? 72 : 232, flex: "none", background: "#001529",
        display: "flex", flexDirection: "column", transition: "width .2s", overflow: "hidden" }}>
        <div style={{ height: 60, display: "flex", alignItems: "center", gap: 10, padding: collapsed ? "0 22px" : "0 20px", flex: "none" }}>
          <span style={{ width: 28, height: 28, borderRadius: 7, background: "var(--color-primary)", color: "#fff",
            display: "inline-flex", alignItems: "center", justifyContent: "center", flex: "none" }}>
            <SH_Icon name="robot" size={16} />
          </span>
          {!collapsed ? <span style={{ color: "#fff", fontSize: 17, fontWeight: 600, whiteSpace: "nowrap" }}>my-agents</span> : null}
        </div>
        <div style={{ flex: 1, overflow: "auto", paddingTop: 4 }}>
          <SH_Menu mode="inline" theme="dark" collapsed={collapsed} selectedKey={view} onSelect={setView} items={[
            { key: "overview", label: "개요", icon: "dashboard" },
            { key: "agents", label: "에이전트", icon: "robot" },
            { key: "blocks", label: "빌딩 블록", icon: "appstore" },
            { key: "sessions", label: "세션", icon: "comment" },
            { key: "approvals", label: collapsed ? "승인" : (<span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>승인 {pendingApprovals ? <span style={{ background: "var(--purple-6)", color: "#fff", borderRadius: 10, fontSize: 11, lineHeight: "16px", minWidth: 16, height: 16, padding: "0 5px", textAlign: "center" }}>{pendingApprovals}</span> : null}</span>), icon: "check-circle" },
            { type: "group", label: collapsed ? "" : "도구", children: [
              { key: "debug", label: "Playground", icon: "thunderbolt" },
            ] },
          ]} />
        </div>
        <div style={{ flex: "none", padding: 12, borderTop: "1px solid rgba(255,255,255,.08)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "6px 8px" }}>
            <SH_Avatar size="small" style={{ background: "var(--volcano-6)" }}>U</SH_Avatar>
            {!collapsed ? <div style={{ color: "rgba(255,255,255,.85)", fontSize: 13, lineHeight: 1.2 }}>
              <div style={{ fontWeight: 500 }}>나</div>
              <div style={{ color: "rgba(255,255,255,.45)", fontSize: 11 }}>개인 워크스페이스</div>
            </div> : null}
          </div>
        </div>
      </aside>

      {/* Main */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
        <header style={{ height: 60, flex: "none", background: "#fff", borderBottom: "1px solid var(--color-border-secondary)",
          display: "flex", alignItems: "center", gap: 16, padding: "0 24px 0 0" }}>
          <button onClick={() => setCollapsed((c) => !c)} style={{ width: 60, height: 60, border: "none", background: "transparent",
            cursor: "pointer", color: "var(--color-text)", fontSize: 18, display: "inline-flex", alignItems: "center", justifyContent: "center" }}>
            <SH_Icon name="menu" />
          </button>
          <h3 style={{ fontSize: 18, margin: 0 }}>{titles[view]}</h3>
          {isEmbed ? <span style={{ fontSize: 12, color: "var(--color-text-tertiary)", border: "1px solid var(--color-border-secondary)", borderRadius: 100, padding: "2px 10px" }}>임베드된 앱</span> : null}
          <div style={{ flex: 1 }} />
          {!isEmbed ? <div style={{ width: 220 }}><SH_Input prefixIcon="search" placeholder="검색" allowClear /></div> : null}
        </header>

        <div style={{ flex: 1, overflow: "auto", display: "flex", flexDirection: "column" }}>
          {view === "overview" ? <window.OverviewView onGo={setView} /> : null}
          {view === "agents" ? <window.AgentsView /> : null}
          {view === "blocks" ? <window.BlocksView /> : null}
          {view === "sessions" ? <window.SessionsView /> : null}
          {view === "approvals" ? <window.ApprovalsView /> : null}
          {isEmbed ? <iframe key={view} src={embeds[view]} title={titles[view]}
            style={{ flex: 1, width: "100%", border: "none", display: "block" }} /> : null}
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<AdminShell />);
