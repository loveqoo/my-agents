/* Ant Design X chat kit — sidebar (logo + conversations). */
const NS = window.AntDesignSystem_b19dda;
const { Conversations, Icon } = NS;

function ChatSidebar({ collapsed, threads, activeKey, onActive, onNew }) {
  if (collapsed) return null;
  return (
    <aside style={{
      width: 280, flex: "none", height: "100%", display: "flex", flexDirection: "column",
      background: "var(--color-bg-layout)", borderRight: "1px solid var(--color-border-secondary)",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "18px 20px", flex: "none" }}>
        <img src="../../assets/icons/ant-design.svg" alt="" style={{ width: 26, height: 26 }} />
        <span style={{ fontSize: 17, fontWeight: 600, color: "var(--color-text-heading)" }}>Ant Design X</span>
      </div>
      <div style={{ flex: 1, minHeight: 0, display: "flex" }}>
        <Conversations
          style={{ flex: 1 }}
          activeKey={activeKey}
          onActiveChange={onActive}
          onCreate={onNew}
          items={threads}
        />
      </div>
      <div style={{ flex: "none", padding: 12, borderTop: "1px solid var(--color-border-secondary)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 8px", borderRadius: 8, cursor: "pointer" }}>
          <span style={{ width: 28, height: 28, borderRadius: "50%", background: "var(--volcano-6)", color: "#fff", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 13 }}>L</span>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 14, fontWeight: 500 }}>나</div>
            <div style={{ fontSize: 12, color: "var(--color-text-tertiary)" }}>무료 플랜</div>
          </div>
          <Icon name="setting" size={16} style={{ color: "var(--color-text-tertiary)" }} />
        </div>
      </div>
    </aside>
  );
}

window.ChatSidebar = ChatSidebar;
