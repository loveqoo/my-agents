/* Ant Design X chat kit — conversation data + a tiny fake "assistant". */

/* Predefined agents (chat over A2A) and the raw materials for a "direct" chat. */
window.CHAT_AGENTS = [
  { id: "research", name: "리서치 어시스턴트", model: "claude-sonnet-4", persona: "체계적인 리서처", mcps: ["tavily", "filesystem"] },
  { id: "reviewer", name: "코드 리뷰어", model: "gpt-4o", persona: "깐깐한 시니어 엔지니어", mcps: ["github", "filesystem"] },
  { id: "secretary", name: "개인 비서", model: "claude-sonnet-4", persona: "따뜻하고 꼼꼼한", mcps: ["gcal", "gmail", "notion"] },
];
window.CHAT_MODELS = [
  { label: "claude-sonnet-4", value: "claude-sonnet-4" },
  { label: "claude-haiku-4", value: "claude-haiku-4" },
  { label: "gpt-4o", value: "gpt-4o" },
  { label: "gpt-4o-mini", value: "gpt-4o-mini" },
];
window.CHAT_MCPS = ["tavily", "filesystem", "github", "prometheus", "kubernetes", "gcal", "gmail", "notion"];

window.CHAT_THREADS = [
  { group: "오늘", items: [
    { key: "t1", label: "AI 채팅 UI 만들기", icon: "message" },
    { key: "t2", label: "Ant Design X 컴포넌트", icon: "message" },
  ]},
  { group: "지난 7일", items: [
    { key: "t3", label: "사이드바 리팩터링", icon: "message" },
    { key: "t4", label: "SQL 쿼리 최적화", icon: "message" },
    { key: "t5", label: "여행 계획: 항저우", icon: "message" },
  ]},
];

/* Seed messages per thread. role: "ai" | "me". */
window.CHAT_SEED = {
  t1: [
    { role: "ai", text: "안녕하세요! Ant Design X예요. AI 인터페이스를 설계하고 만드는 걸 도와드릴 수 있어요. 무엇을 만들어 볼까요?" },
    { role: "me", text: "ChatGPT 같은 깔끔한 채팅 화면을 원해요." },
    { role: "ai", text: "좋은 선택이에요. RICH 패러다임은 Welcome, Bubble, Prompts, Sender, Conversations를 제공해요 — 지금 보시는 화면도 전부 그 요소들로 만들어졌어요. 무엇이든 바꿔달라고 말씀해 주세요." },
  ],
  t2: [
    { role: "ai", text: "Ant Design X는 엔터프라이즈급 LLM 컴포넌트를 제공해요: Bubble, Conversations, Sender, Prompts, Welcome, Attachments, ThoughtChain 등 — 모두 antd 토큰으로 테마를 입힐 수 있어요." },
  ],
  t3: [], t4: [], t5: [],
};

window.CHAT_PROMPTS = [
  { key: "p1", icon: "bulb", iconColor: "var(--gold-6)", label: "아이디어 떠올리기", description: "내 제품 이름 브레인스토밍" },
  { key: "p2", icon: "fire", iconColor: "var(--volcano-6)", label: "지금 뜨는 주제", description: "이번 주 AI 핫토픽" },
  { key: "p3", icon: "read", iconColor: "var(--green-6)", label: "요약하기", description: "긴 문서를 짧게 정리" },
  { key: "p4", icon: "thunderbolt", iconColor: "var(--color-primary)", label: "코드 작성", description: "React 컴포넌트 생성" },
];

/* A canned streaming-ish reply. Returns the full text; the UI fakes the typing. */
window.fakeReply = function fakeReply(prompt) {
  const p = (prompt || "").toLowerCase();
  if (p.includes("코드") || p.includes("code") || p.includes("react") || p.includes("컴포넌트") || p.includes("component")) {
    return "간단한 React 컴포넌트예요:\n\nfunction Hello({ name }) {\n  return <h1>Hello, {name}!</h1>;\n}\n\n어디든 넣고 name prop을 넘기면 돼요. Ant Design 토큰으로 스타일을 입혀 드릴까요?";
  }
  if (p.includes("이름") || p.includes("name") || p.includes("아이디어") || p.includes("idea") || p.includes("브레인") || p.includes("brainstorm")) {
    return "몇 가지 방향이에요:\n• Lumen — 차분하고 지적인\n• Atlas — 든든하고 폭넓은\n• Drift — 자연스러운 흐름\n• Beacon — 안내 중심\n\n특정 느낌으로 더 변주해 볼까요?";
  }
  if (p.includes("트렌드") || p.includes("trend") || p.includes("핫") || p.includes("hot")) {
    return "이번 주 AI 흐름: 에이전틱 워크플로, 온디바이스 소형 모델, 스트리밍 UI 패턴이 곳곳에서 보여요. Ant Design X의 RICH 인터랙션 패러다임이 바로 이런 스트리밍·멀티스텝 경험을 위해 만들어졌어요.";
  }
  if (p.includes("요약") || p.includes("summar")) {
    return "좋아요 — 텍스트를 붙여넣거나 파일을 첨부해 주시면 핵심 3줄 요약과 한 줄 TL;DR을 드릴게요.";
  }
  return "알겠어요. 저라면 이렇게 접근할게요: 사용자의 목표에서 출발해, 그 목표에 필요한 최소한의 컴포넌트를 배치하고, 그다음 간격과 카피를 다듬어요. 더 알려 주시면 구체적으로 도와드릴게요.";
};
