/* Ant Design X chat kit — TargetBar: choose what you're talking to.
   Two modes:
     • Agent  — pick a predefined agent; the chat runs over the A2A protocol.
     • Direct — pick an LLM model and manually attach MCP servers.
   The target is per-conversation and locks once the thread has messages. */
const NS_TB = window.AntDesignSystem_b19dda;
const { Select: TB_Select, Tag: TB_Tag, Icon: TB_Icon, RadioGroup: TB_Radio, Button: TB_Button } = NS_TB;

window.targetSummary = function targetSummary(target) {
  if (!target) return "새 채팅";
  if (target.mode === "agent") {
    const a = window.CHAT_AGENTS.find((x) => x.id === target.agentId);
    return a ? a.name : "에이전트 선택";
  }
  return target.model || "모델 선택";
};

function McpPicker({ value, onChange }) {
  const remaining = window.CHAT_MCPS.filter((m) => !value.includes(m));
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
      {value.map((m) => (
        <TB_Tag key={m} color="cyan" closable onClose={() => onChange(value.filter((x) => x !== m))}>{m}</TB_Tag>
      ))}
      {remaining.length ? (
        <div style={{ width: 168 }}>
          <TB_Select size="small" placeholder="+ MCP 서버 추가" value={undefined}
            options={remaining.map((m) => ({ label: m, value: m }))}
            onChange={(v) => onChange([...value, v])} />
        </div>
      ) : <span style={{ fontSize: 12, color: "var(--color-text-quaternary)" }}>모두 추가됨</span>}
    </div>
  );
}

function TargetBar({ target, locked, onChange }) {
  const t = target || { mode: "agent", agentId: null, model: "claude-sonnet-4", mcps: [] };
  const agent = t.mode === "agent" ? window.CHAT_AGENTS.find((a) => a.id === t.agentId) : null;

  return (
    <div style={{ flex: "none", borderBottom: "1px solid var(--color-border-secondary)", background: "var(--color-bg-container)", padding: "10px 20px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
        {locked ? (
          <TB_Tag color={t.mode === "agent" ? "green" : "blue"}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
              <TB_Icon name={t.mode === "agent" ? "robot" : "thunderbolt"} size={11} />
              {t.mode === "agent" ? "에이전트 · A2A" : "직접 연결"}
            </span>
          </TB_Tag>
        ) : (
          <TB_Radio optionType="button" value={t.mode}
            onChange={(mode) => onChange({ ...t, mode })}
            options={[{ label: "에이전트", value: "agent" }, { label: "직접 연결", value: "direct" }]} />
        )}

        {t.mode === "agent" ? (
          <React.Fragment>
            <div style={{ width: 210 }}>
              <TB_Select size="small" placeholder="에이전트 선택" value={t.agentId || undefined}
                disabled={locked}
                options={window.CHAT_AGENTS.map((a) => ({ label: a.name, value: a.id }))}
                onChange={(agentId) => onChange({ ...t, agentId })} />
            </div>
            {agent ? (
              <React.Fragment>
                <TB_Tag color="green"><span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}><TB_Icon name="global" size={10} />A2A</span></TB_Tag>
                <span style={{ fontSize: 12, color: "var(--color-text-tertiary)", fontFamily: "var(--font-family-code)" }}>{agent.model}</span>
                <span style={{ display: "inline-flex", gap: 4 }}>{agent.mcps.map((m) => <TB_Tag key={m} color="cyan">{m}</TB_Tag>)}</span>
              </React.Fragment>
            ) : <span style={{ fontSize: 12, color: "var(--color-text-tertiary)" }}>A2A 프로토콜로 대화합니다.</span>}
          </React.Fragment>
        ) : (
          <React.Fragment>
            <div style={{ width: 180 }}>
              <TB_Select size="small" placeholder="모델" value={t.model || undefined} disabled={locked}
                options={window.CHAT_MODELS} onChange={(model) => onChange({ ...t, model })} />
            </div>
            <span style={{ width: 1, height: 18, background: "var(--color-border-secondary)" }} />
            {locked
              ? <span style={{ display: "inline-flex", gap: 4 }}>{(t.mcps || []).length ? t.mcps.map((m) => <TB_Tag key={m} color="cyan">{m}</TB_Tag>) : <span style={{ fontSize: 12, color: "var(--color-text-tertiary)" }}>MCP 없음</span>}</span>
              : <McpPicker value={t.mcps || []} onChange={(mcps) => onChange({ ...t, mcps })} />}
          </React.Fragment>
        )}
      </div>
    </div>
  );
}

window.TargetBar = TargetBar;
