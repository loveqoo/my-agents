# X Chat UI Kit — Ant Design X AI conversation

A high-fidelity, interactive recreation of an **Ant Design X** AI chat interface —
the RICH-paradigm LLM UI built on top of antd. Every surface is composed from this
design system's own X component primitives (`window.AntDesignSystem_b19dda`).

## Run
Open [`index.html`](index.html). It loads `styles.css`, the compiled
`_ds_bundle.js`, the chat data, then the kit's JSX modules.

## Flow (all fake / local)
1. **Sidebar** — `Conversations` history grouped by date with a tinted *New
   conversation* button and a user footer.
2. **Empty state** — a `Welcome` hero + `Prompts` starter cards. Click a prompt to
   send it.
3. **Chat** — type and press **Enter** (Shift+Enter = newline). Your message lands
   as an `end` bubble; the assistant replies with a **fake streamed** `start`
   bubble (blinking typing cursor → settled text + copy/retry/like/dislike actions).
4. **Stop** — while streaming, the `Sender` send button becomes a **stop** button.
5. **New chat** — creates a fresh thread; its title auto-renames to your first
   message.
6. **Switch threads** — click any conversation to load its messages.
7. **Collapse** — the header menu button hides the sidebar.

## Choosing a target (Agent vs Direct)
Each conversation has a **target**, set in the bar under the header:
- **Agent** — pick a predefined agent; the chat runs over the **A2A** protocol. The
  agent brings its own model and MCP servers (shown read-only).
- **Direct** — pick an **LLM model** and manually **attach MCP servers** (add /
  remove chips). No agent involved.

The target is editable while the conversation is empty and **locks** once the first
message is sent (you can't change a running session's nature). The sender is
disabled until a target is chosen.

## Files
- `index.html` — shell + script loader (also a Starting Point).
- `chatData.js` — thread list, seed messages, starter prompts, and the canned
  `fakeReply()` "assistant".
- `ChatSidebar.jsx` — logo + `Conversations` + user footer.
- `ChatConversation.jsx` — header, empty state (`Welcome` + `Prompts`), message
  `Thread` (`Bubble`/`BubbleList`), and the `Sender` composer.
- `ChatApp.jsx` — root shell: thread state, fake streaming, new-chat, prompt seeding.

## Components exercised
`Welcome`, `Bubble`/`BubbleList`, `Prompts`, `Sender`, `Conversations` (the X set),
plus `Avatar`, `Button`, `Tag`, `Icon` from the base system.

The streaming is simulated in the browser (no network); swap `fakeReply()` for a
real model call to make it live.
