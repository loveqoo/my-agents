/* Ant Design X chat kit — app shell. Wires sidebar + conversation, thread state,
   fake streaming replies, new-chat creation and prompt seeding. */

function ChatApp() {
  const [collapsed, setCollapsed] = React.useState(false);
  const [threads, setThreads] = React.useState(window.CHAT_THREADS);
  const [msgs, setMsgs] = React.useState(window.CHAT_SEED);
  const [active, setActive] = React.useState("t1");
  const [streaming, setStreaming] = React.useState(false);
  const timer = React.useRef(null);

  // Per-thread target: agent (A2A) or direct (model + MCP).
  const [targets, setTargets] = React.useState({
    t1: { mode: "agent", agentId: "research", model: "claude-sonnet-4", mcps: [] },
    t2: { mode: "direct", model: "gpt-4o", mcps: ["tavily"] },
    t3: { mode: "agent", agentId: "reviewer", model: "gpt-4o", mcps: [] },
    t4: { mode: "direct", model: "claude-haiku-4", mcps: ["filesystem"] },
    t5: { mode: "agent", agentId: "secretary", model: "claude-sonnet-4", mcps: [] },
  });
  const target = targets[active] || { mode: "agent", agentId: null, model: "claude-sonnet-4", mcps: [] };
  const setTarget = (next) => setTargets((ts) => ({ ...ts, [active]: next }));

  const titleFor = (key) => {
    for (const g of threads) {
      const hit = g.items.find((i) => i.key === key);
      if (hit) return hit.label;
    }
    return "새 대화";
  };

  const stop = () => {
    if (timer.current) { clearInterval(timer.current); timer.current = null; }
    setStreaming(false);
  };

  const streamReply = (key, full) => {
    setStreaming(true);
    // push an empty AI message we'll fill in
    setMsgs((m) => ({ ...m, [key]: [...(m[key] || []), { role: "ai", text: "" }] }));
    let i = 0;
    const step = Math.max(2, Math.round(full.length / 90));
    timer.current = setInterval(() => {
      i += step;
      const slice = full.slice(0, i);
      setMsgs((m) => {
        const arr = (m[key] || []).slice();
        arr[arr.length - 1] = { role: "ai", text: slice };
        return { ...m, [key]: arr };
      });
      if (i >= full.length) { clearInterval(timer.current); timer.current = null; setStreaming(false); }
    }, 40);
  };

  const send = (text) => {
    if (streaming) return;
    const key = active;
    setMsgs((m) => ({ ...m, [key]: [...(m[key] || []), { role: "me", text }] }));
    // rename a fresh thread to the first user message
    setThreads((ts) => ts.map((g) => ({
      ...g,
      items: g.items.map((it) => it.key === key && it.label === "새 대화"
        ? { ...it, label: text.slice(0, 32) } : it),
    })));
    setTimeout(() => streamReply(key, window.fakeReply(text)), 280);
  };

  const newChat = () => {
    stop();
    const key = "n" + Date.now();
    setThreads((ts) => {
      const rest = ts.filter((g) => g.group !== "오늘");
      const today = ts.find((g) => g.group === "오늘");
      const items = [{ key, label: "새 대화", icon: "message" }, ...(today ? today.items : [])];
      return [{ group: "오늘", items }, ...rest];
    });
    setMsgs((m) => ({ ...m, [key]: [] }));
    setTargets((ts) => ({ ...ts, [key]: { mode: "agent", agentId: null, model: "claude-sonnet-4", mcps: [] } }));
    setActive(key);
  };

  const switchThread = (key) => { stop(); setActive(key); };

  return (
    <div style={{ height: "100%", display: "flex", background: "var(--color-bg-container)" }}>
      <window.ChatSidebar
        collapsed={collapsed}
        threads={threads}
        activeKey={active}
        onActive={switchThread}
        onNew={newChat}
      />
      <window.ChatConversation
        title={titleFor(active)}
        messages={msgs[active] || []}
        streaming={streaming}
        target={target}
        onTargetChange={setTarget}
        onSend={send}
        onStop={stop}
        onToggleSidebar={() => setCollapsed((c) => !c)}
      />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<ChatApp />);
