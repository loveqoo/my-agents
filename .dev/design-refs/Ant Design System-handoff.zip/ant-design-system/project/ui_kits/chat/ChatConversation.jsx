/* Ant Design X chat kit — the conversation pane: header, empty-state welcome +
   prompts, message thread, and the sender composer. */
const NS = window.AntDesignSystem_b19dda;
const { Welcome, Bubble, BubbleList, Prompts, Sender, Avatar, Icon, Button, Tag } = NS;

const aiAvatar = <Avatar style={{ background: "var(--color-primary)", flex: "none" }}><Icon name="robot" /></Avatar>;
const meAvatar = <Avatar style={{ background: "var(--volcano-6)", flex: "none" }}>L</Avatar>;

function MsgActions({ onCopy }) {
  return (
    <React.Fragment>
      <Button type="text" size="small" iconName="copy" onClick={onCopy} />
      <Button type="text" size="small" iconName="sync" />
      <Button type="text" size="small" iconName="like" />
      <Button type="text" size="small" iconName="dislike" />
    </React.Fragment>
  );
}

function ChatHeader({ onToggle, title, target }) {
  const isAgent = target && target.mode === "agent";
  return (
    <header style={{
      height: 56, flex: "none", display: "flex", alignItems: "center", gap: 12,
      padding: "0 20px", borderBottom: "1px solid var(--color-border-secondary)", background: "var(--color-bg-container)",
    }}>
      <Button type="text" iconName="menu" onClick={onToggle} />
      <span style={{ fontSize: 15, fontWeight: 500, color: "var(--color-text-heading)", flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{title}</span>
      <Tag color={isAgent ? "green" : "blue"}>
        <span style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
          <Icon name={isAgent ? "robot" : "thunderbolt"} size={11} />{window.targetSummary(target)}
        </span>
      </Tag>
      <Button type="text" iconName="share-alt" />
    </header>
  );
}

function EmptyState({ onPrompt, target }) {
  const agent = target && target.mode === "agent" ? window.CHAT_AGENTS.find((a) => a.id === target.agentId) : null;
  const direct = target && target.mode === "direct";
  const title = agent ? `${agent.name}와 대화 중` : direct ? `직접 대화 · ${target.model}` : "시작하려면 에이전트나 모델을 고르세요";
  const desc = agent
    ? `${agent.persona} 에이전트와 A2A 프로토콜로 대화합니다. 도구: ${agent.mcps.join(", ")}.`
    : direct
      ? `모델 직접 세션입니다. ${(target.mcps || []).length ? "연결된 MCP: " + target.mcps.join(", ") + "." : "연결된 MCP 서버가 없습니다 — 위에서 추가하세요."}`
      : "미리 정의된 에이전트(A2A)를 고르거나, 모델을 선택하고 위 바에서 MCP 서버를 연결하세요.";
  return (
    <div style={{ maxWidth: 760, margin: "0 auto", width: "100%", padding: "7vh 24px 0", display: "flex", flexDirection: "column", gap: 28 }}>
      <Welcome
        icon={agent ? <Avatar style={{ background: "var(--gray-12)", flex: "none" }} size={56}><Icon name="robot" size={26} /></Avatar> : <img src="../../assets/icons/ant-design.svg" alt="" style={{ width: 56 }} />}
        title={title}
        description={desc}
      />
      <Prompts title="✨ 시작하기" wrap items={window.CHAT_PROMPTS} onItemClick={(it) => onPrompt(it.description || it.label)} />
    </div>
  );
}

function Thread({ messages, streaming }) {
  const endRef = React.useRef(null);
  React.useEffect(() => { if (endRef.current) endRef.current.scrollTop = endRef.current.scrollHeight; }, [messages, streaming]);
  return (
    <div ref={endRef} style={{ flex: 1, overflowY: "auto" }}>
      <div style={{ maxWidth: 760, margin: "0 auto", padding: "24px", width: "100%", boxSizing: "border-box" }}>
        <BubbleList gap={20}>
          {messages.map((m, i) => (
            m.role === "ai" ? (
              <Bubble key={i} placement="start" avatar={aiAvatar} header="Ant Design X"
                content={m.text}
                typing={streaming && i === messages.length - 1}
                footer={!(streaming && i === messages.length - 1) ? <MsgActions onCopy={() => navigator.clipboard && navigator.clipboard.writeText(m.text)} /> : null} />
            ) : (
              <Bubble key={i} placement="end" variant="filled" avatar={meAvatar} content={m.text} />
            )
          ))}
        </BubbleList>
      </div>
    </div>
  );
}

function ChatConversation({ title, messages, streaming, target, onTargetChange, onSend, onStop, onToggleSidebar }) {
  const empty = messages.length === 0;
  const ready = target && (target.mode === "agent" ? !!target.agentId : !!target.model);
  return (
    <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", background: "var(--color-bg-container)" }}>
      <ChatHeader onToggle={onToggleSidebar} title={title} target={target} />
      <window.TargetBar target={target} locked={!empty} onChange={onTargetChange} />
      {empty ? (
        <div style={{ flex: 1, overflowY: "auto" }}>
          <EmptyState onPrompt={onSend} target={target} />
        </div>
      ) : (
        <Thread messages={messages} streaming={streaming} target={target} />
      )}
      <div style={{ flex: "none", padding: "8px 24px 20px" }}>
        <div style={{ maxWidth: 760, margin: "0 auto" }}>
          <Sender
            placeholder={ready ? "무엇이든 물어보세요…" : "위에서 에이전트나 모델을 먼저 고르세요…"}
            loading={streaming}
            disabled={!ready}
            onSubmit={onSend}
            onCancel={onStop}
            prefix={<Button type="text" iconName="paper-clip" />}
            actions={<Button type="text" iconName="audio" />}
            footer={<span style={{ fontSize: 12, color: "var(--color-text-tertiary)" }}>{target && target.mode === "agent" ? "A2A로 라우팅 · Enter로 전송" : "모델 직접 호출 · Enter로 전송"}</span>}
          />
        </div>
      </div>
    </div>
  );
}

window.ChatConversation = ChatConversation;
