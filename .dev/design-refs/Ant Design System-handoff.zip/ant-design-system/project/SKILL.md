---
name: ant-design-design
description: Use this skill to generate well-branded interfaces and assets for Ant Design (antd), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Quick map:
- `styles.css` — link this one file; it `@import`s all tokens. Theme by overriding CSS custom properties (e.g. `--color-primary`).
- `tokens/` — colors (13 preset palettes + neutrals + semantic aliases), typography (native system stack, 14px base), spacing/radius/shadow/motion.
- `components/` — React primitives (Button, Input, Select, Switch, Checkbox, Radio, Card, Tag, Badge, Avatar, Alert, Modal, Menu, Tabs, Breadcrumb, Icon). Each has a `.prompt.md` with usage. Load `_ds_bundle.js` and read from `window.AntDesignSystem_b19dda`.
- `components/x/` — **Ant Design X** AI primitives (Welcome, Bubble/BubbleList, Prompts, Sender, Conversations) for building LLM chat interfaces.
- `assets/icons/` + `assets/icons.js` — Ant Design outlined icon SVGs; use the `Icon` component.
- `ui_kits/admin/` — full Ant Design Pro-style dashboard recreation.
- `ui_kits/chat/` — full Ant Design X AI chat recreation (streaming bubbles, prompts, sender).

Brand essentials: one blue (`#1677ff`), neutral information-first UI, flat white/`#f5f5f5` surfaces, 4px spacing unit, 6px radius, 32px controls, hairline borders, soft three-layer shadows, native system font, no emoji, no gradients, Title Case buttons with no terminal periods.
